#include <iostream>
using namespace std;

void test(){
    printf("aksjdaisjdj");
}

int main() {
    
}
