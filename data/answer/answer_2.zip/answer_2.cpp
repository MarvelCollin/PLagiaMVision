#include <iostream>
using namespace std;

int main() {







}

void test() {
    printf("aksjdaisjdasdasdsadj"); 
    }