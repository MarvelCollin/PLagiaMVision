#include <stdio.h>

int main(){
	printf("AWIKWG");
	return 0;
}
