#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <iostream>
#include <Windows.h>

void printBoard();
char board[3][3];
const char PLAYER = 'T';
const char BOT = 'Z';


	
int main(){	
	printf("\n\nWelcome to Galactic Fear! \n\n");
	
	printf("1. Play \n");
	printf("2. Exit \n");
	
	int ans;
	scanf("%d Select an option: ", &ans);
	    
	if(ans == 1){
		printf("Select difficulty: \n");
		printf("1. Easy \n");
		printf("2. Hard \n");
		
		int newAns;
		scanf("%d Select an option: ", &newAns);
		
		
		char winner = ' ';
		char response = ' ';
		
		do{
			winner = ' ';
			response = ' ';
			resetBoard();
			
			while(winner == ' ' && checkFreeSpaces() == 0){
			printBoard();
				
			playerMove();
			winner = checkWinner();
	         if(winner != ' ' || checkFreeSpaces() == 0)
	         {
	            break;
	         }
	
	         computerMove();
	         winner = checkWinner();
	         if(winner != ' ' || checkFreeSpaces() == 0)
	         {
	            break;
	         }
			}
		}
		
	}else if(ans == 2){
		printf("Thank you for Play the game!");
	}
	
	return 0;
	
}

void printBoard()
{
   printf(" %c | %c | %c ", board[0][0], board[0][1], board[0][2]);
   printf("\n---|---|---\n");
   printf(" %c | %c | %c ", board[1][0], board[1][1], board[1][2]);
   printf("\n---|---|---\n");
   printf(" %c | %c | %c ", board[2][0], board[2][1], board[2][2]);
   printf("\n");
}

void playerMove(){
	char x;
	char y;
	
	do
   {
      printf("Enter row #(a,b,c): ");
      scanf("%c", &x);
      x--;
      printf("Enter column #(a,b,c): ");
      scanf("%c", &y);
      y--;

      if(board[x][y] != ' ')
      {
         printf("Invalid move!\n");
      }
      else
      {
         board[x][y] = PLAYER;
         break;
      }
   } while (board[x][y] != ' ');
	
	
}
