#include<stdio.h>

char board[3][3];
const char player = 'T';
const char bot = 'Z';

void printboard(){
	printf(" %c | %c | %c ", board[0][0], board[0][1], board[0][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[1][0], board[1][1], board[1][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[2][0], board[2][1], board[2][2]);
	printf("\n");
}

//void playerMove(){
//	int x;
//	int y;
//	
//	do{
//		printf("You are playing as 'T' and the bot is playing as 'Z'.\n");
//		printf("\n");
//		printf("To make a move, enter the row and column using letters 'a' 'b' 'c'.\n");
//		printf("For example, to mark the top-left corner, input: a a\n");
//		printf("Enter your move (row[a-c] and column[a-c]): ");
//		scanf("%c %c", &x, &y);
//		x--;
//		y--;
//		if(board[x][y] != ' '){
//			printf("Invalid move! The cell is either occupied. Try again.\n");
//		}
//		else{
//			board[x][y] = player;
//			break;
//		}
//	}
//	while (board[x][y] != ' ');
//}

int main(){
	int checkmenu = 1;
	int a;
	printf("Welcome to gaLactic Fear!\n");
	printf("1. Play\n");
	printf("2. Exit\n");
	printf("Select an option:\n");
	scanf("%d", &a);
	
	if(a==1){
		int difficulty;
		printf("Select difficulty:\n");
		printf("1. Easy\n");
		printf("2. Hard\n");
		printf("Select an option:\n");	
		scanf("%d", &difficulty);
		while(difficulty >2 || difficulty < 1){
			printf("Invalid option! Please choose 1 For easy of 2 for Hard.\n");
			printf("Select an option: ");	
			scanf("%d", &difficulty);
		}
		if(difficulty == 1){
			printboard();
			char row, column;
			printf("You are playing as 'T' and the bot is playing as 'Z'.\n");
			printf("\n");
			printf("To make a move, enter the row and column using letters 'a' 'b' 'c'.\n");
			printf("For example, to mark the top-left corner, input: a a\n");
			printf("Enter your move (row[a-c] and column[a-c]): ");
			scanf("%c %c", &row, &column);
		}
		else if(difficulty == 2){
			printboard();
			char row, column;
			printf("You are playing as 'T' and the bot is playing as 'Z'.\n");
			printf("\n");
			printf("To make a move, enter the row and column using letters 'a' 'b' 'c'.\n");
			printf("For example, to mark the top-left corner, input: a a\n");
			printf("Enter your move (row[a-c] and column[a-c]): ");
			scanf("%c %c", &row, &column);
		}	
	}
	while(a==2){
		return 0;
	}
	while(a<1 || a>2){
		scanf("%d", &a);
	}
	return 0;
}
