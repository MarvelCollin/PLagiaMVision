#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

#define SIZE 3
#define Player T
#define Computer Z

void GameOver();
void Hardmode();
void EasyMode();
void CD();
void menu();

	char game[SIZE][SIZE] = {
		{'_','_','_'},
		{'_','_','_'},
		{'_','_','_'}
	};
	
	
int main(){
	menu();
	return 0;
}
	
	
	
void menu(){

	int selection;
	printf("Welcome to gaLactic Fear!\n");
	printf("1. Play\n");
	printf("2. Exit\n");
	printf(">> ");
	scanf("%d", &selection);
	getchar();
	switch(selection){
		case 1 : system("cls");
					CD();
		
	
		case 2 : system("cls");
		
		default : menu() ;
}
}

void CD(){

	int selectDiff;
	printf("Select Difficulty:\n");
	printf("1. Easy\n");
	printf("2. Hard\n");
	printf(">> ");
	scanf("%d", &selectDiff);
	getchar();
	switch(selectDiff){
		case 1 : system("cls");
					EasyMode(); break;
				
					
	/*				
		case 2 : system("cls");
					HardMode(); break;
	*/								
	
	}
	}


void EasyMode(){
	int r, c;
	for(int i = 0; i<SIZE;i++){
		for(int j = 0; i<SIZE;j++){
			printf("%c",game[i][j]);
		}
	
	}	printf("\n");
	printf("You're playing as T and the computer as Z.\n");
	printf("Insert Row And Column : ");
	scanf("%c %c", &r, &c);
	game[r - 1][c - 1]= 'Z';
	
	
}
void Ezc(){
	int MoveE = 1+(rand() % 9);
	int CRE = 
	int CCE =
	
}


void GameOver(){
	if (GameWin){
		
	printf("You Win! Press Any Key To Return To Menu");
	getchar();}
	
	else if (Gamelose){
	printf("You Lose! Press Any Key To Return To The Menu");
	}
}