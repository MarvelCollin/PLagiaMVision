#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>

char board[3][3];
const char you = 'T';
const char com = 'Z';

void clear();
void generate();
int cek();
void playerM();
void comMeasy();
void cekwin();

int main(){
	int u = 'n';
	char winner = ' ';	
	
	do{
		winner = ' ';
		
//		while(winner != ' ' && cek() != 0){
//system("cls");
			clear();
			generate();
		
			playerM();
			comMeasy();
			cekwin();
//		}		
		
				
	}while(u != 'y');
				
	return 0;
}

void clear(){
	for(int i=0; i<3; i++){
		for(int j=0; j<3; j++){
			board[i][j] == ' ';
		}
	}		
}

void generate(){
	printf(" %c |  %c | %c \n", board[0][0], board[0][1], board[0][2]);
	printf("---|--- |---\n");
	printf(" %c |  %c | %c \n", board[1][0], board[1][1], board[1][2]);
	printf("---|--- |---\n");
	printf( "%c |  %c | %c \n", board[2][0], board[2][1], board[2][2]);
}

int cek(){
	int sisa = 9;
	
	for(int i=0; i<3; i++){
		for(int j=0; j<3; j++){
			if(board[i][j] != ' '){
				sisa--;
			}
		}
	}	
	
	return sisa;
}

void playerM(){
	char u = 'n', x, y;
	int x1, y1;
	
	do{
		do{
			printf("Masukan koordinat (row[1-3] dan col[1-3] pakai spasi) : ");
			scanf("%d %d", &x1, &y1);
			printf("\n");
		}while(x1 > 3 || x1 < 1 || y1 > 3 || y1 < 1 );
		
//		switch(x){
//			case 'a':
//				x1 = 0;
//			break;
//			case 'b':
//				x1 = 1;
//			break;
//			case 'c':
//				x1 = 2;
//			break;
//			default:
//				u = 'y';
//			break;
//		}
//		
//		switch(y){
//			case 'a':
//				y1 = 0;
//			break;
//			case 'b':
//				y1 = 1;
//			break;
//			case 'c':
//				y1 = 2;
//			break;
//			default:
//				u = 'y';
//			break;
//		}
		
			if(board[x1][y1] == ' '){
				printf("Masukan angka yang benar!!");
				u = 'y';
			}else{
				board[x1-1][y1-1] = you;
				break;
			}	
				
	}while(board[x1][y1] == ' ');
}

void comMeasy(){
	int x, y;
	char u;
	
	srand(time(0));
	
	do{
		if(cek() > 0){
			do{
				x = rand() % 3;
				y = rand() % 3;
			}while(board[x][y] != ' ');
			
			board[x][y] = com;
			break;
		}else{
			break;
		}
		
	}while(u == 'y');
}

void cekwin(){
	char winner = ' ';
	
	for(int i=0; i<3; i++){
		if(board[i][0] == board[i][1] || board[i][1] == board[i][2]){
			winner = board[i][0];
		}else if(board[0][i] == board[1][i] || board[1][i] == board[2][i]){
			winner = board[0][i];
		}
	}
	
		if(board[0][0] == board[1][1] || board[1][1] == board[2][2]){
			winner = board[0][0];
		}
		
		if(board[0][2] == board[1][1] || board[1][1] == board[2][0]){
			winner = board[0][2];
		}
}

