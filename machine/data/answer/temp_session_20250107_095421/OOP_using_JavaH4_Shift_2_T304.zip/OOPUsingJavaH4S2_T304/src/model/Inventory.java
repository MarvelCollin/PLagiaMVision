package model;

public class Inventory {
	private int wood;
	private int stone;
	private int gold;
	private int money;
	
	public Inventory() {
		super();
		this.wood = 40;
		this.stone = 40;
		this.gold = 40;
		this.money = 0;
	}

	public int getWood() {
		return wood;
	}

	public void setWood(int wood) {
		this.wood = wood;
	}

	public int getStone() {
		return stone;
	}

	public void setStone(int stone) {
		this.stone = stone;
	}

	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}	

}
