package model;

public class goldFactory extends Factory {

	public goldFactory(int wood, int stone, int gold, int money) {
		super(wood, stone, gold, money);
		// TODO Auto-generated constructor stub
	}

}
