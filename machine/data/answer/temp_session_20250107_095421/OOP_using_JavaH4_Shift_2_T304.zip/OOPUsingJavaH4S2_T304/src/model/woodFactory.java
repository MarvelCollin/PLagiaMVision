package model;

public class woodFactory extends Factory {

	public woodFactory(int wood, int stone, int gold, int money) {
		super(wood, stone, gold, money);
		// TODO Auto-generated constructor stub
	}

}
