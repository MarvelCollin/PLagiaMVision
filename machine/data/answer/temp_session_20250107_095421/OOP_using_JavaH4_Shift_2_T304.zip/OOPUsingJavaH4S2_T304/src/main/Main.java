package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.Factory;
import model.Inventory;

public class Main {
	
	Scanner scan = new Scanner(System.in);
	int day = 1;
	int score = 0;
	Inventory item = new Inventory();
	ArrayList<Factory> factoryList = new ArrayList<>();

	public Main() {
		mainMenu();
	}
	
	public void mainMenu() {
		while(true) {
			enter();
			System.out.println("  /\\  /\\/\\  /\\/ __\\_ _  ___| |_ ___  _ __ _   _\r\n" + 
					" / /_/ / /_/ / _\\/ _` |/ __| __/ _ \\| '__| | | |\r\n" + 
					"/ __  / __  / / | (_| | (__| || (_) | |  | |_| |\r\n" + 
					"\\/ /_/\\/ /_/\\/   \\__,_|\\___|\\__\\___/|_|   \\__, |\r\n" + 
					"                                          |___/");
			System.out.println();
			System.out.println("1. Play game");
			System.out.println("2. Exit");
			System.out.print(">> ");
			int option;
			try {
				option = scan.nextInt();
			} catch (Exception e) {
				option = -1;
			}
			scan.nextLine();
			if(option == 2) return;
			else if(option == 1) {
				playGame();
			}
		}
	}
	
	public void playGame() {
		while(true) {
			enter();
			System.out.println("Day "+ day);
			System.out.println("===================");
			System.out.println("| Your resources  |");
			System.out.println("===================");
			System.out.printf("| Wood: %-9d |\n", item.getWood());
			System.out.printf("| Stone: %-9d|\n", item.getStone());
			System.out.printf("| Gold: %-9d |\n", item.getGold());
			System.out.printf("| Money: %-9d|\n", item.getMoney());
			System.out.println("===================");
			System.out.println();
			System.out.println("Actions:");
			System.out.println("1. Finish day");
			System.out.println("2. Buy factory");
			System.out.println("3. View all factory");
			System.out.println("4. Trade center");
			System.out.println("5. Exit game");
			System.out.println();
			System.out.print("Choose action [1-5]: ");
			int choice;
			try {
				choice = scan.nextInt();
			} catch (Exception e) {
				choice = -1;
			}
			scan.nextLine();
			if(choice == 5) {
				gameOver();
				break;
			} else if(choice == 4) {
				tradeCenter();
			} else if(choice == 3) {
				viewFactory();
			} else if(choice == 2) {
				buyFactory();
			} else if(choice == 1) {
				finishDay();
			}
			
		}
	}
	
	public void tradeCenter() {
		
	}
	
	public void viewFactory() {
		if(factoryList.isEmpty()) {
			enter();
			System.out.println("You don't own a single factory!");
			System.out.println();
			System.out.println("Press enter to continue...");
			scan.nextLine();
		}
	}
	
	public void buyFactory() {
		while(true) {
			enter();
			System.out.println("===================");
			System.out.println("| Your resources  |");
			System.out.println("===================");
			System.out.printf("| Wood: %-9d |\n", item.getWood());
			System.out.printf("| Stone: %-9d|\n", item.getStone());
			System.out.printf("| Gold: %-9d |\n", item.getGold());
			System.out.printf("| Money: %-9d|\n", item.getMoney());
			System.out.println("===================");
			System.out.println();
			System.out.println("  Buy factory");
			System.out.println("========================");
			System.out.println("| No | Type            |");
			System.out.println("========================");
			System.out.println("| 1  | Wood factory    |");
			System.out.println("| 2  | Stone factory   |");
			System.out.println("| 3  | Gold factory    |");
			System.out.println("========================");
			System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
			System.out.println();
			System.out.print("Choose factory [1-3], [0] to go back: ");
			int choice1;
			try {
				choice1 = scan.nextInt();
			} catch (Exception e) {
				choice1 = -1;
			}
			scan.nextLine();
			if(choice1 == 0) {
				break;
			} else if(choice1 == 1) {
				buyWoodFactory();
			}
		}
		
	}
	
	public void finishDay() {
		System.out.println();
		System.out.println("Going to next day....");
		System.out.println();
		System.out.println("Press enter to continue...");
		scan.nextLine();
		day++;
	}
	
	public void gameOver() {
		day = 1;
		enter();
		System.out.println("GAMEOVER");
		System.out.println("===============");
		System.out.println("Final score: "+ score);
		System.out.println();
		System.out.println("Press enter to continue...");
		scan.nextLine();
	}
	
	public void buyWoodFactory() {
		enter();
		System.out.println("Input factory detail");
		System.out.println("=========================");
		String name;
		String type;
		do {
			System.out.println("Input factory name [5 - 15 characters] (inclusive): ");
			name = scan.nextLine();
			if(name.length() < 5 || name.length() > 15) {
				System.out.println("Factory name must be 5-15 characters (inclusive)!");
			}
		} while(name.length() < 5 || name.length() > 15);
	}
	
	public void buyStoneFactory() {
		
	}
	
	public void buyGoldFactory() {
		
	}
	
	
	
	public void enter() {
		System.out.println("\n".repeat(100));
	}

	public static void main(String[] args) {
		new Main();
	}

}
