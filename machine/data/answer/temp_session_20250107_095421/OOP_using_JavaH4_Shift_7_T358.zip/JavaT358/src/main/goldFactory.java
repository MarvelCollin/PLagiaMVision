package main;

public class goldFactory {

	 
	public goldFactory() {
		super();
	}

}
