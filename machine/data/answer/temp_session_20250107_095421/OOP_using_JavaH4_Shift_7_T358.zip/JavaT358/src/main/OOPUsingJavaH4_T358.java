package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
     
    private int wood;
    private int stone;
    private int gold;
    private int money;
    private int day;

  
    private List<Factory> factories;

     
    public Main() {
       
        this.wood = 40;
        this.stone = 40;
        this.gold = 40;
        this.money = 0;  
        this.day = 1;  
        this.factories = new ArrayList<>(); / 
    }

    
    private void displayResources() {
        System.out.println("--- Day: " + day + " ---");
        System.out.println("Resources:");
        System.out.println("Wood: " + wood);
        System.out.println("Stone: " + stone);
        System.out.println("Gold: " + gold);
        System.out.println("Money: " + money);
        System.out.println();
    }

 
    private void displayMenu() {
        System.out.println("1. Play game");
        System.out.println("2. Exit");
        System.out.print(">> ");
    } 
    public void gameplayMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;  

        while (running) {
            displayResources();  

            System.out.println("--- Gameplay Menu ---");
            System.out.println("1. Finish Day");
            System.out.println("2. Buy Factory");
            System.out.println("3. View All Factories");
            System.out.println("4. Trade Center");
            System.out.println("5. Exit Game");

            
            int choice = 0;
            boolean validInput = false;

            while (!validInput) {
                System.out.print(">> ");
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                    if (choice >= 1 && choice <= 5) {
                        validInput = true;  
                    } else {
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next();  
                }
            }

             
            switch (choice) {
                case 1:
                    finishDay();
                    break;
                case 2:
                    buyFactory();
                    break;
                case 3:
                    viewAllFactories();
                    break;
                case 4:
                    tradeCenter();
                    break;
                case 5:
                    exitGame();
                    running = false;  
                    break;
                default:
                    break;  
            }
        }

        scanner.close();  
    }

    public void woodFactory() {
    	
    }
    
    public void goldFactory() {
    	
    }
    
    public void tradeCenter() {
    	
    }
    
    private void finishDay() {
        System.out.println("Finishing the day...");

        
        for (Factory factory : factories) {
            wood += factory.getWoodProduction();
            stone += factory.getStoneProduction();
            gold += factory.getGoldProduction();
            money += factory.getMoneyProduction();
        }

         
        System.out.println("Trade offers have been refreshed.");

 
        day++;
    }

 
    private void buyFactory() {
 
        Factory newFactory = new Factory("New Factory", "Type1", 5, "Special Ability");  
        factories.add(newFactory);
        System.out.println("You have bought a new factory!");
    }

    private void viewAllFactories() {
        if (factories.isEmpty()) {
            System.out.println("You do not have any factories.");
        } else {
            System.out.println("You own the following factories:");
            for (Factory factory : factories) {
                System.out.println(factory);  
            }
        }
    }

 
    class Factory {
        private String name;
        private String type;
        private int productionValue;
        private String specialAttribute;
        private int woodProduction;
        private int stoneProduction;
        private int goldProduction;
        private int moneyProduction;

        public Factory(String name, String type, int productionValue, String specialAttribute) {
            this.name = name;
            this.type = type;
            this.productionValue = productionValue;
            this.specialAttribute = specialAttribute;
            
            this.woodProduction = productionValue; 
            this.stoneProduction = productionValue;  
            this.goldProduction = productionValue;  
            this.moneyProduction = productionValue;  
        }

        public int getWoodProduction() {
            return woodProduction;
        }

        public int getStoneProduction() {
            return stoneProduction;
        }

        public int getGoldProduction() {
            return goldProduction;
        }

        public int getMoneyProduction() {
            return moneyProduction;
        }

        @Override
        public String toString() {
            return "Factory Name: " + name +
                   ", Type: " + type +
                   ", Production Value: " + productionValue +
                   ", Special Attribute: " + specialAttribute;
        }
    }

    
    private void tradeCenter() {
        System.out.println("Redirecting to Trade Center Page...");
       
    }

     
    private void exitGame() {
        System.out.println("Exiting the game...");
        System.out.println("Your final score is: " + money);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Main game = new Main();  

        / 
        game.displayMenu();

         
        int choice = scanner.nextInt();  
 
        switch (choice) {
            case 1:
               
                game.gameplayMenu();
                break;
            case 2:
                
                System.out.println("Exiting the program. Goodbye!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }

        scanner.close();  
    }
}
