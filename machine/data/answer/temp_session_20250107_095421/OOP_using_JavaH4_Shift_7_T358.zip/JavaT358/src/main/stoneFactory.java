package main;

public class stoneFactory extends Factory {

	/**
	 * 
	 */
	public stoneFactory() {
		super();
	}
  
}
