package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    // Resource variables
    private int wood;
    private int stone;
    private int gold;
    private int money;
    private int day;

    // List to store owned factories
    private List<Factory> factories;

    // Constructor to initialize resources and day
    public Main() {
        // Initialize resources
        this.wood = 40;
        this.stone = 40;
        this.gold = 40;
        this.money = 0; // Initial money can be set to 0 or any desired value
        this.day = 1; // Start on day 1
        this.factories = new ArrayList<>(); // Initialize the list of factories
    }

    // Method to display current resources and day
    private void displayResources() {
        System.out.println("--- Day: " + day + " ---");
        System.out.println("Resources:");
        System.out.println("Wood: " + wood);
        System.out.println("Stone: " + stone);
        System.out.println("Gold: " + gold);
        System.out.println("Money: " + money);
        System.out.println();
    }

    // Method to display the main menu
    private void displayMenu() {
        System.out.println("1. Play game");
        System.out.println("2. Exit");
        System.out.print(">> ");
    }

    // Method to display the gameplay menu
    public void gameplayMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true; // Flag to control the menu loop

        while (running) {
            displayResources(); // Show resources before displaying gameplay options

            System.out.println("--- Gameplay Menu ---");
            System.out.println("1. Finish Day");
            System.out.println("2. Buy Factory");
            System.out.println("3. View All Factories");
            System.out.println("4. Trade Center");
            System.out.println("5. Exit Game");

            // Prompt user for input and validate
            int choice = 0;
            boolean validInput = false;

            while (!validInput) {
                System.out.print(">> ");
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                    if (choice >= 1 && choice <= 5) {
                        validInput = true; // Valid input received
                    } else {
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a number.");
                    scanner.next(); // Clear the invalid input
                }
            }

            // Handle user's choice
            switch (choice) {
                case 1:
                    finishDay();
                    break;
                case 2:
                    buyFactory();
                    break;
                case 3:
                    viewAllFactories();
                    break;
                case 4:
                    tradeCenter();
                    break;
                case 5:
                    exitGame();
                    running = false; // Exit the loop
                    break;
                default:
                    break; // This case won't be hit due to previous validation
            }
        }

        scanner.close(); // Close the scanner when done
    }

    // Method to finish the day
    private void finishDay() {
        System.out.println("Finishing the day...");

        // Produce resources from all factories
        for (Factory factory : factories) {
            wood += factory.getWoodProduction();
            stone += factory.getStoneProduction();
            gold += factory.getGoldProduction();
            money += factory.getMoneyProduction();
        }

        // Refresh trade offers in trade center (placeholder for future logic)
        System.out.println("Trade offers have been refreshed.");

        // Increment the day
        day++;
    }

    // Method to buy a factory
    private void buyFactory() {
        // Here you can modify the attributes accordingly to suit your game logic
        Factory newFactory = new Factory("New Factory", "Type1", 5, "Special Ability"); // Example factory with production values
        factories.add(newFactory);
        System.out.println("You have bought a new factory!");
    }

    private void viewAllFactories() {
        if (factories.isEmpty()) {
            System.out.println("You do not have any factories.");
        } else {
            System.out.println("You own the following factories:");
            for (Factory factory : factories) {
                System.out.println(factory); // Calls the toString method of the Factory class
            }
        }
    }

    // Factory class to represent each factory
    class Factory {
        private String name;
        private String type;
        private int productionValue;
        private String specialAttribute;
        private int woodProduction;
        private int stoneProduction;
        private int goldProduction;
        private int moneyProduction;

        public Factory(String name, String type, int productionValue, String specialAttribute) {
            this.name = name;
            this.type = type;
            this.productionValue = productionValue;
            this.specialAttribute = specialAttribute;
            // Initialize production values as needed
            this.woodProduction = productionValue; // Example assignment, adjust as necessary
            this.stoneProduction = productionValue; // Example assignment, adjust as necessary
            this.goldProduction = productionValue; // Example assignment, adjust as necessary
            this.moneyProduction = productionValue; // Example assignment, adjust as necessary
        }

        public int getWoodProduction() {
            return woodProduction;
        }

        public int getStoneProduction() {
            return stoneProduction;
        }

        public int getGoldProduction() {
            return goldProduction;
        }

        public int getMoneyProduction() {
            return moneyProduction;
        }

        @Override
        public String toString() {
            return "Factory Name: " + name +
                   ", Type: " + type +
                   ", Production Value: " + productionValue +
                   ", Special Attribute: " + specialAttribute;
        }
    }

    // Method to handle trade center
    private void tradeCenter() {
        System.out.println("Redirecting to Trade Center Page...");
        // Logic for trade center goes here
    }

    // Method to exit the game and show final score
    private void exitGame() {
        System.out.println("Exiting the game...");
        System.out.println("Your final score is: " + money);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Main game = new Main(); // Create a new game instance

        // Display the main menu
        game.displayMenu();

        // Get user input
        int choice = scanner.nextInt(); // Read the user's choice

        // Handle user's choice
        switch (choice) {
            case 1:
                // If user chooses "Play game", show the gameplay menu
                game.gameplayMenu();
                break;
            case 2:
                // If user chooses "Exit", terminate the program
                System.out.println("Exiting the program. Goodbye!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }

        scanner.close(); // Close the scanner when done
    }
}
