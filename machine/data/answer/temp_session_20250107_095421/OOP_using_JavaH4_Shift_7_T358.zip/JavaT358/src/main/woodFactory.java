package main;

public class woodFactory {
 
	public woodFactory() {
		super();
	}
	
	

}
