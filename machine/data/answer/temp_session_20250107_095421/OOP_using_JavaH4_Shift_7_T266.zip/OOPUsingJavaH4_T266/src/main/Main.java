package main;

import io.IO;
import module.Game;

public class Main {

	public Main() {
		displayMenu();
	}
	
	public void displayMenu() {
		IO.clear();
		System.out.print("               ___          _\r\n"
				+ "  /\\  /\\/\\  /\\/ __\\_ _  ___| |_ ___  _ __ _   _\r\n"
				+ " / /_/ / /_/ / _\\/ _` |/ __| __/ _ \\| '__| | | |\r\n"
				+ "/ __  / __  / / | (_| | (__| || (_) | |  | |_| |\r\n"
				+ "\\/ /_/\\/ /_/\\/   \\__,_|\\___|\\__\\___/|_|   \\__, |\r\n"
				+ "                                          |___/\r\n"
				+ "\r\n"
				+ "1. Play game\r\n"
				+ "2. Exit\r\n"
				+ ">> ");
		String in;
		in = IO.scan.nextLine();
		if (in.equals("1")) new Game();
		else if (in.equals("2")) return;
		else displayMenu();
	}

	public static void main(String[] args) {
		new Main();
	}

}
