package module;

public class StoneFactory extends Factory {
	
	private String stoneType;

	public StoneFactory(String name, String type, String stoneType) {
		super(name, type);
		this.stoneType = stoneType;
	}

	public String getStoneType() {
		return stoneType;
	}

	public void setStoneType(String stoneType) {
		this.stoneType = stoneType;
	}
	
	public String displayInfo() {
		return "Stone type: " + this.stoneType;
	}
}
