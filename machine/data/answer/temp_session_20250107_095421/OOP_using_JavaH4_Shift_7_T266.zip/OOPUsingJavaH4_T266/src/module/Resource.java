package module;

public class Resource {
	
	private int wood;
	private int stone;
	private int gold;
	private int money;
	
	public Resource(int wood, int stone, int gold, int money) {
		super();
		this.wood = wood;
		this.stone = stone;
		this.gold = gold;
		this.money = money;
	}

	public int getWood() {
		return wood;
	}

	public void setWood(int wood) {
		this.wood = wood;
	}

	public int getStone() {
		return stone;
	}

	public void setStone(int stone) {
		this.stone = stone;
	}

	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public void displayResource() {
		System.out.println("===================");
		System.out.println("| Your resources  |");
		System.out.println("===================");
		System.out.format("| Wood: %-9d |\n", this.wood);
		System.out.format("| Stone: %-8d |\n", this.stone);
		System.out.format("| Gold: %-9d |\n", this.gold);
		System.out.format("| Money: %-8d |\n", this.money);
		System.out.println("===================");
	}

}
