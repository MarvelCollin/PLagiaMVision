package module;

public class Factory {
	
	private String name;
	private String type;
	private int productionValue;

	public Factory(String name, String type) {
		super();
		this.name = name;
		this.type = type;
		this.productionValue = 3;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getProductionValue() {
		return productionValue;
	}

	public void setProductionValue(int productionValue) {
		this.productionValue = productionValue;
	}
	
	public String displayInfo() {
		return null;
	}

}
