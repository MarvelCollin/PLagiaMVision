package module;

public class GoldFactory extends Factory {

	private int goldPurity;

	public GoldFactory(String name, String type, int goldPurity) {
		super(name, type);
		this.goldPurity = goldPurity;
	}

	public int getGoldPurity() {
		return goldPurity;
	}

	public void setGoldPurity(int goldPurity) {
		this.goldPurity = goldPurity;
	}
	
	public String displayInfo() {
		return "Gold purity: " + this.goldPurity;
	}

}
