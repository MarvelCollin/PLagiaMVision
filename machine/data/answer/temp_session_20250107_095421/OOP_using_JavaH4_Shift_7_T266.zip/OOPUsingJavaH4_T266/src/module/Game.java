package module;

import java.util.ArrayList;

import javax.print.attribute.standard.Finishings;

import io.IO;
import main.Main;

public class Game {
	
	private int day;
	private ArrayList<Factory> factories = new ArrayList<Factory>();
	private Resource resource = new Resource(40, 40, 40, 0);
	private ArrayList<Trade> trades = new ArrayList<Trade>();

	public Game() {
		this.day = 1;
		for (int i = 0; i < 3; i++) trades.add(new Trade());
		displayGameMenu();
	}
	
	public void displayGameMenu() {
		IO.clear();
		System.out.println("Day: " + day);
		resource.displayResource();
		System.out.print("Actions:\r\n"
				+ "1. Finish day\r\n"
				+ "2. Buy factory\r\n"
				+ "3. View all factory\r\n"
				+ "4. Trade center\r\n"
				+ "5. Exit game\r\n"
				+ "\r\n"
				+ "Choose action [1-5]: ");
		String in;
		in = IO.scan.nextLine();
		if (in.equals("1")) nextDay();
		else if (in.equals("2")) newFactory();
		else if (in.equals("3")) viewAllFactory();
		else if (in.equals("4")) displayTrades();
		else if (in.equals("5")) exit();
		else displayGameMenu();
	}
	
	public void exit() {
		IO.clear();
		System.out.println("GAMEOVER");
		System.out.println("==============");
		System.out.println("Final score: " + resource.getMoney());
		IO.enter();
		new Main();
		return;
	}
	
	public void nextDay() {
		for (Factory factory : factories) {
			if (factory.getType().equals("Wood")) resource.setWood(resource.getWood() + factory.getProductionValue());
			else if (factory.getType().equals("Stone")) resource.setStone(resource.getStone() + factory.getProductionValue());
			else if (factory.getType().equals("Gold")) resource.setGold(resource.getGold() + factory.getProductionValue());
		}
		trades.clear();
		for (int i = 0; i < 3; i++) trades.add(new Trade());
		day++;
		
		System.out.println("Going to next day ...");
		
		IO.enter();
		
		displayGameMenu();
		
	}
	
	public void newFactory() {
		IO.clear();
		resource.displayResource();
		
		System.out.println("Buy factory");
		
		System.out.print("========================\r\n"
				+ "| No | Type            |\r\n"
				+ "========================\r\n"
				+ "| 1  | Wood factory    |\r\n"
				+ "| 2  | Stone factory   |\r\n"
				+ "| 3  | Gold factory    |\r\n"
				+ "========================\r\n"
				+ "To buy any type of factory you need: 12 Wood, 12 Stone and 12 Gold.\r\n"
				+ "\r\n"
				+ "Choose factory [1-3], [0] to go back: ");
		
		String in;
		in = IO.scan.nextLine();
		if (in.equals("1")) {
			if (resource.getWood() < 12 && resource.getStone() < 12 && resource.getGold() < 12) {
				System.out.println("You don't have enough resources!");
				IO.enter();
				displayGameMenu();
				return;
			}
			IO.clear();
			String name, type;
			do {
				System.out.print("Input factory name [5 - 15 characters] (inclusive): ");
				name = IO.scan.nextLine();
				if (5 <= name.length() && name.length() <= 15) break;
				else System.out.println("Factory name must be 5-15 characters (inclusive)!");
			} while (true);
			
			do {
				System.out.print("Input wood type [Teak | Mahogany | Oak] (case sensitive): ");
				type = IO.scan.nextLine();
				if (type.equals("Teak") || type.equals("Mahogany") || type.equals("Oak")) break;
				else System.out.println("Wood type must be Teak, Mahogany, or Oak (case sensitive)!");
			} while (true);
			
			factories.add(new WoodFactory(name, "Wood", type));
			resource.setWood(resource.getWood()-12);
			resource.setStone(resource.getStone()-12);
			resource.setGold(resource.getGold()-12);
			
			System.out.println("Successfully bought a new factory!");
			IO.enter();
		} else if (in.equals("2")) {
			if (resource.getWood() < 12 && resource.getStone() < 12 && resource.getGold() < 12) {
				System.out.println("You don't have enough resources!");
				IO.enter();
				displayGameMenu();
				return;
			}
			IO.clear();
			String name, type;
			do {
				System.out.print("Input factory name [5 - 15 characters] (inclusive): ");
				name = IO.scan.nextLine();
				if (5 <= name.length() && name.length() <= 15) break;
				else System.out.println("Factory name must be 5-15 characters (inclusive)!");
			} while (true);
			
			do {
				System.out.print("Input wood type [Granite | Marble | Limestone] (case sensitive): ");
				type = IO.scan.nextLine();
				if (type.equals("Granite") || type.equals("Marble") || type.equals("Limestone")) break;
				else System.out.println("Stone type must be Granite, Marble, or Limestone (case sensitive)!");
			} while (true);
			
			factories.add(new StoneFactory(name, "Stone", type));
			resource.setWood(resource.getWood()-12);
			resource.setStone(resource.getStone()-12);
			resource.setGold(resource.getGold()-12);
			
			System.out.println("Successfully bought a new factory!");
			IO.enter();
		} else if (in.equals("3")) {
			
			if (resource.getWood() < 12 && resource.getStone() < 12 && resource.getGold() < 12) {
				System.out.println("You don't have enough resources!");
				IO.enter();
				displayGameMenu();
				return;
			}
			IO.clear();
			String name;
			int purity;
			do {
				System.out.print("Input factory name [5 - 15 characters] (inclusive): ");
				name = IO.scan.nextLine();
				if (5 <= name.length() && name.length() <= 15) break;
				else System.out.println("Factory name must be 5-15 characters (inclusive)!");
			} while (true);
			
			while (true) {
				try {
					System.out.print("Input gold purity [16 - 22] (inclusive): ");
					purity = IO.scan.nextInt();
					IO.scan.nextLine();
					if (16 <= purity && purity <= 22) break;
					else System.out.println("Gold purity must be between 16 - 22 (inclusive)!");
				} catch (Exception e) {
					IO.scan.nextLine();
					System.out.println("Gold purity must be between 16 - 22 (inclusive)!");
				}
			}
			
			
			factories.add(new GoldFactory(name, "Gold", purity));
			resource.setWood(resource.getWood()-12);
			resource.setStone(resource.getStone()-12);
			resource.setGold(resource.getGold()-12);
			
			System.out.println("Successfully bought a new factory!");
			IO.enter();
		} else if (in.equals("0")) displayGameMenu();
		newFactory();
	}
	
	public void viewAllFactory() {
		IO.clear();
		System.out.println("============================================================================");
		System.out.println("| Name             | Type       | Production Value | Special Attribute     |");
		System.out.println("============================================================================");
		for (Factory factory : factories) {
			System.out.format("| %-16s | %-10s | %-16d | %-21s |\n", factory.getName(), factory.getType(), factory.getProductionValue(), factory.displayInfo());
		}
		System.out.println("============================================================================");
		IO.enter();
		displayGameMenu();
	}

	public void displayTrades() {
		IO.clear();
		if (trades.size() == 0) {
			System.out.println("There is no trade offer for today!");
			IO.enter();
			displayGameMenu();
			return;
		}
		resource.displayResource();
		System.out.println("Trade Center");
		System.out.println("================================");
		System.out.println("| No | Cost       | Reward     |");
		System.out.println("================================");
		int counter = 1;
		for (Trade trade : trades) {
			System.out.format("| %-2d | %d %-7s | %d MONEY  |\n", counter, trade.getCost(), trade.getType(), trade.getReward());
			counter++;
		}
		System.out.println("================================");
		
		
		int in;
		try {
			System.out.print("Choose offer [1-" + trades.size() + "] [0] to go back: ");
			in = IO.scan.nextInt();
			IO.scan.nextLine();
			if (in > trades.size()) {
				displayTrades();
				return;
			}
		} catch (Exception e) {
			IO.scan.nextLine();
			displayTrades();
			return;
		}
		if (in == 0) {
			displayGameMenu();
			return;
		}
		in--;
		if (trades.get(in).getType().equals("WOOD")) {
			if (resource.getWood() < trades.get(in).getCost()) System.out.println("You don't have enough resource!");
			else {
				resource.setWood(resource.getWood()-trades.get(in).getCost());
				resource.setMoney(resource.getMoney() + trades.get(in).getReward());
				trades.remove(in);
				System.out.println("Transaction completed successfully!");
			}
		} else if (trades.get(in).getType().equals("STONE")) {
			if (resource.getStone() < trades.get(in).getCost()) System.out.println("You don't have enough resource!");
			else {
				resource.setStone(resource.getStone()-trades.get(in).getCost());
				resource.setMoney(resource.getMoney() + trades.get(in).getReward());
				trades.remove(in);
				System.out.println("Transaction completed successfully!");
			}
		} else if (trades.get(in).getType().equals("GOLD")) {
			if (resource.getGold() < trades.get(in).getCost()) System.out.println("You don't have enough resource!");
			else {
				resource.setGold(resource.getGold() - trades.get(in).getCost());
				resource.setMoney(resource.getMoney() + trades.get(in).getReward());
				trades.remove(in);
				System.out.println("Transaction completed successfully!");
			}
		}
		IO.enter();
		displayTrades();
	}
}
