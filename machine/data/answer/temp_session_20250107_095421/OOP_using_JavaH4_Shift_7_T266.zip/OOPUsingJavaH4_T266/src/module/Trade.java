package module;

import java.util.Random;

public class Trade {
	
	private int cost, reward;
	private String type;

	public Trade() {
		Random rand = new Random();
		this.cost = rand.nextInt(11) + 10;
		this.reward = 100;
		int type2 = rand.nextInt(3);
		if (type2 == 0) this.type = "WOOD";
		else if (type2 == 1) this.type = "STONE";
		else if (type2 == 2) this.type = "GOLD";
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getReward() {
		return reward;
	}

	public void setReward(int reward) {
		this.reward = reward;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	

}
