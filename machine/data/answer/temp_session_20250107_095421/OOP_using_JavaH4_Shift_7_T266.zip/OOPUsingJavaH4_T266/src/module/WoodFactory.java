package module;

public class WoodFactory extends Factory {

	private String woodType;

	public WoodFactory(String name, String type, String woodType) {
		super(name, type);
		this.woodType = woodType;
	}

	public String getWoodType() {
		return woodType;
	}

	public void setWoodType(String woodType) {
		this.woodType = woodType;
	}
	
	public String displayInfo() {
		return "Wood type: " + this.woodType;
	}

}
