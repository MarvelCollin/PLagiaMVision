package io;

import java.util.Scanner;

public class IO {
	
	public static Scanner scan = new Scanner(System.in);

	public IO() {
		// TODO Auto-generated constructor stub
	}
	
	public static void clear() {
		for (int i = 0; i < 30; i++) System.out.println();
	}
	
	public static void enter() {
		System.out.println("Press ENTER to continue...");
		scan.nextLine();
	}

}
