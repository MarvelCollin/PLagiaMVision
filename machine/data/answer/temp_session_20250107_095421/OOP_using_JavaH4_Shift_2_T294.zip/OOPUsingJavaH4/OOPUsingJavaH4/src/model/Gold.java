package model;

public class Gold extends Resources{
	
	String name;
	Integer purity;
	
	public Gold(Integer wood, Integer stone, Integer gold, Integer money, String name, Integer purity) {
		super(wood, stone, gold, money);
		this.name = name;
		this.purity = purity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getPurity() {
		return purity;
	}
	public void setPurity(Integer purity) {
		this.purity = purity;
	}




	

}
