package model;

public class Stone extends Resources{
	
	String name;
	String stoneType;
	
	public Stone(Integer wood, Integer stone, Integer gold, Integer money, String name, String stoneType) {
		super(wood, stone, gold, money);
		this.name = name;
		this.stoneType = stoneType;
	}
	public Stone(String name2, String stoneType2) {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStoneType() {
		return stoneType;
	}
	public void setStoneType(String stoneType) {
		this.stoneType = stoneType;
	}



	
	

}
