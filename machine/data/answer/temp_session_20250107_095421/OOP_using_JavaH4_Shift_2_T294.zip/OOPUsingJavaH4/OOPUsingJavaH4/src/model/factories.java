package model;

public class factories {
	
	private Integer woodFactory;
	private Integer stoneFactory;
	private Integer goldFactory;
	
	public factories(Integer woodFactory, Integer stoneFactory, Integer goldFactory) {
		super();
		this.woodFactory = woodFactory;
		this.stoneFactory = stoneFactory;
		this.goldFactory = goldFactory;
	}
	
	public void fact()
	{
		
	}
	
	public Integer getWoodFactory() {
		return woodFactory;
	}
	public void setWoodFactory(Integer woodFactory) {
		this.woodFactory = woodFactory;
	}
	public Integer getStoneFactory() {
		return stoneFactory;
	}
	public void setStoneFactory(Integer stoneFactory) {
		this.stoneFactory = stoneFactory;
	}
	public Integer getGoldFactory() {
		return goldFactory;
	}
	public void setGoldFactory(Integer goldFactory) {
		this.goldFactory = goldFactory;
	}

	

}
