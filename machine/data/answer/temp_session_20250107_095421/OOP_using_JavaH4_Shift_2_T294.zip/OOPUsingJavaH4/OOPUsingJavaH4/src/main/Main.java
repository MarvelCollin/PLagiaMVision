package main;


import model.Resources;
import model.factories;
import model.Gold;
import model.Stone;
import model.Wood;


public class Main {
	
	int day = 1;
	int Gold = 40;
	int Stone = 40;
	int Wood = 40;
	int Money = 0;
	ArrayList<Resources> factList = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	
	public Main() {
	//1. Add new person
		while(true)
		{
			System.out.println("\n".repeat(50));
			System.out.println("1. Play Game");
			System.out.println("2. Exit");
			System.out.print(">> ");
			int choice = sc.nextInt();
			sc.nextLine();
			if(choice == 2) break;
			else if(choice == 1) playGame();
		}
		System.out.println("Goodbye!");
	}
	
	public void playGame()
	{

		while(true)
		{
			System.out.println("\n".repeat(50));
			System.out.println("   Day: " + day);
		    System.out.println("Your resources: ");
		    System.out.println("Wood: " + Wood);
		    System.out.println("Stone: " + Stone);
		    System.out.println("Gold: " + Gold);
		    System.out.println("Money: " + Money);
			System.out.println("");
			System.out.println("");
			System.out.println("Actions: ");
			System.out.println("1. Finish day");
			System.out.println("2. Buy factory");
			System.out.println("3. View all factory");
			System.out.println("4. Trade center");
			System.out.println("5. Exit game");
			System.out.print(">> ");
			int choice = sc.nextInt();
			sc.nextLine();
			if(choice == 5) break;
			if(choice == 4) tradeCenter();
			if(choice == 3) viewFactory();
			if(choice == 2) buyFactory();
			if(choice == 1) nextDay();
		}
		System.out.println("Press 'Enter' to continue...");
		sc.nextLine();
	}
private void tradeCenter()
{
	
}

private void viewFactory()
{
	
}
		
private void nextDay()
{
	System.out.println("\n".repeat(50));
	System.out.println("Going to the next day...");
	System.out.println("");
	System.out.println("Press 'Enter' to continue...");
	sc.nextLine();
}

private void buyFactory()
{
	while(true)
	{
	System.out.println("\n".repeat(50));
    System.out.println("Your resources: ");
    System.out.println("Wood: " + Wood);
    System.out.println("Stone: " + Stone);
    System.out.println("Gold: " + Gold);
    System.out.println("Money: " + Money);
	System.out.println("");
	System.out.println("");
	System.out.println("Buy factory: ");
	System.out.println("1. Wood factory");
	System.out.println("2. Stone factory");
	System.out.println("3. Gold factory");
	System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
	System.out.println("");
	System.out.print("Choose factory [1-3], [0] to go back: ");
	int choice = sc.nextInt();
	sc.nextLine();
	if (Wood < 10 || Stone <10 || Gold <10)
	{
		System.out.println("You don't have enough resources.");
		System.out.println("Press 'Enter' to continue...");
		sc.nextLine();
	}
	else if (choice == 1)
	{
		String name, woodType;
		while(true)
		{
			System.out.println("Input factory name: ");
			name=sc.nextLine();
		    if(name.length() > 4 || name.length() < 16)break;
		}
		while(true)
		{
			System.out.println("Input wood type [Teak | Mahogany | Oak]: ");
			woodType=sc.nextLine();
		    if(woodType.equalsIgnoreCase("Teak") || woodType.equalsIgnoreCase("Mahogany") || woodType.equalsIgnoreCase("Oak"))break;
		}
		Wood -= 10;
		Stone -= 10;
		Gold -= 10;
		System.out.println("Successfully bought a new factory!");
		System.out.println("");
		System.out.println("Press 'Enter' to continue...");
		sc.nextLine();
		factList.add(new Wood(name, woodType));
	}
	else if (choice == 2)
	{
		String name, stoneType;
		while(true)
		{
			System.out.println("Input factory name: ");
			name=sc.nextLine();
		    if(name.length() > 4 || name.length() < 16)break;
		}
		while(true)
		{
			System.out.println("Input wood type [Granite | Marble | Limestone]: ");
			stoneType=sc.nextLine();
		    if(stoneType.equalsIgnoreCase("Granite") || stoneType.equalsIgnoreCase("Marble") || stoneType.equalsIgnoreCase("Limestone"))break;
		}
		Wood -= 10;
		Stone -= 10;
		Gold -= 10;
		System.out.println("Successfully bought a new factory!");
		System.out.println("");
		System.out.println("Press 'Enter' to continue...");
		sc.nextLine();
		factList.add(new Stone(name, stoneType);

	}
	else if (choice == 3)
	{
		String name;
		Integer purity;
		while(true)
		{
			System.out.println("Input factory name: ");
			name=sc.nextLine();
		    if(name.length() > 4 || name.length() < 16)break;
		}
		while(true)
		{
			System.out.println("Input gold purity [18-24]: ");
			purity=sc.nextInt();
		    if(purity > 17 || purity < 25)break;
		}
		Wood -= 10;
		Stone -= 10;
		Gold -= 10;
		System.out.println("Successfully bought a new factory!");
		System.out.println("");
		System.out.println("Press 'Enter' to continue...");
		sc.nextLine();
	}
	
	
}
}	


	public static void main(String[] args) {
		new Main();

	}

}

//Person person =  new Person("Joe", 69);
//	public Main() {
//		Person p1 = new Lecturer("Budi", 30, "D9999", "OOP", "LF01");
//		p1.introduce();
//		((Lecturer) p1).teach();
//		
//		System.out.println("=".repeat(20));
//		
//		Assistant p2 = new Assistant("Dhuar", 20, "FFS22", "OOP", "FK01");
//	    p2.introduce();
//		p2.teach();
//		System.out.println("=".repeat(20));
//		
//		Student p3 = new Student("Steven", 69, "6969696969", "Computer Science", "LK01");
//		p3.introduce();
//		p3.study();

