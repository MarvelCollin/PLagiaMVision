package model;

public class Resources {
	
	protected Integer Wood = 40;
	protected Integer Stone = 40;
	protected Integer Gold = 40;
	protected Integer Money = 0;
	
	public Resources(Integer wood, Integer stone, Integer gold, Integer money) {
		super();
		Wood = wood;
		Stone = stone;
		Gold = gold;
		Money = money;
	}
	public Integer getWood() {
		return Wood;
	}
	public void setWood(Integer wood) {
		Wood = wood;
	}
	public Integer getStone() {
		return Stone;
	}
	public void setStone(Integer stone) {
		Stone = stone;
	}
	public Integer getGold() {
		return Gold;
	}
	public void setGold(Integer gold) {
		Gold = gold;
	}
	public Integer getMoney() {
		return Money;
	}
	public void setMoney(Integer money) {
		Money = money;
	}
	
	

}
