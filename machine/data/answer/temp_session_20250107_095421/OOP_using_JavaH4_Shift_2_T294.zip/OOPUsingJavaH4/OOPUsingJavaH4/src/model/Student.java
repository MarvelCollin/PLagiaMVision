package model;

public class Student extends Person {
    
	private String nim;
	private String classCode;
	private String major;


	public Student(String name, Integer age, String nim, String classCode, String major) {
		super(name, age);
		this.nim = nim;
		this.classCode = classCode;
		this.major = major;
	}
	public void study()
	{
		System.out.println("Hi my name is "+ name);
		System.out.println("I am studying "+ major +" at BINUS in class "+ classCode +".");
	}
	public String getNim() {
		return nim;
	}


	public void setNim(String nim) {
		this.nim = nim;
	}


	public String getClassCode() {
		return classCode;
	}


	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}


	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}

}
