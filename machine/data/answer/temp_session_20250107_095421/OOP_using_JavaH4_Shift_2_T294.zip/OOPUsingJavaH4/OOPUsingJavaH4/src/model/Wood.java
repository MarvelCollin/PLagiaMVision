package model;

public class Wood extends Resources{
	
	String name;
	String woodType;
	
	public Wood(String name, String woodType) {
		super();
		this.name = name;
		this.woodType = woodType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWoodType() {
		return woodType;
	}
	public void setWoodType(String woodType) {
		this.woodType = woodType;
	}


	
	

}
