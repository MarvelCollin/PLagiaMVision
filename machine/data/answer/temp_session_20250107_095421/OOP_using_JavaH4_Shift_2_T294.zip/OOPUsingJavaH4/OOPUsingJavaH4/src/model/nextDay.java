package model;

public class nextDay {
	
	private Integer day;

	public nextDay(Integer day) {
		super();
		this.day = day;
	}

	public void next()
	{
		day = day + 1;
	}
	public Integer getDay() {
		return day;
	}

	public void setDay(Integer day) {
		this.day = day;
	}
	
	

}
