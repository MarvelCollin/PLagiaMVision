package model;

public class Factory {
	protected String name;
	protected String type;
	protected Integer pValue;
	protected String Attri;
	public Factory(String name, String type, Integer pValue, String attri) {
		super();
		this.name = name;
		this.type = type;
		this.pValue = pValue;
		Attri = attri;
	}
	

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getpValue() {
		return pValue;
	}
	public void setpValue(Integer pValue) {
		this.pValue = pValue;
	}
	public String getAttri() {
		return Attri;
	}
	public void setAttri(String attri) {
		Attri = attri;
	}
	
	
	
	
}
