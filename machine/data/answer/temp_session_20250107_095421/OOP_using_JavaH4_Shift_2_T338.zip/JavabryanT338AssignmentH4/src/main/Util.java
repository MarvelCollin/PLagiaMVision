package main;

public class Util {
	public static void cls() {
		System.out.println("\n".repeat(100));
	}
}
