package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.Factory;

public class Main {
	Scanner sc = new Scanner(System.in);
	int wood = 40, stone = 40, gold = 40, money = 0;
	ArrayList<Factory> factoryList = new ArrayList<>();
	public Main(){
		boolean sikma = false;
		while (!sikma) {
			
		System.out.print(
				 "1. Play game\n" + 
				 "2. Exit\n" + 
				 ">> ");
		int choice1 = sc.nextInt();
		switch (choice1) {
		case 1:
			mainMenu();
			break;
		case 2:
			System.out.println("Good bye");
			break;
		default:
			System.out.println("Invalid input");
			break;
		}
	}
}
	
private void mainMenu() {
	
	int day = 1;
	boolean giga = false;
	while (!giga) {
	System.out.print("Day: "+day+"\r\n" + 
			"===================\r\n" + 
			"| Your resources  |\r\n" + 
			"===================\r\n" + 
			"| Wood: "+wood+"        |\r\n" + 
			"| Stone: "+stone+"       |\r\n" + 
			"| Gold: "+gold+"        |\r\n" + 
			"| Money: "+money+"        |\r\n" + 
			"===================\r\n" + 
			"\r\n" + 
			"Actions:\r\n" + 
			"1. Finish day\r\n" + 
			"2. Buy factory\r\n" + 
			"3. View all factory\r\n" + 
			"4. Trade center\r\n" + 
			"5. Exit game\r\n" + 
			"\r\n" + 
			"Choose action [1-5]: ");
	int choice2 = sc.nextInt();
	switch (choice2) {
	case 1:
		day++;
		System.out.println("Going to next day...");
		System.out.println("Press ENTER to continue");
		sc.nextLine();
		break;
	case 2:
		buyFactory();
		break;
	case 3:
		viewFac();
	default:
		break;
	}
	}
}

private void buyFactory() {
	System.out.print("===================\r\n" + 
			"| Your resources  |\r\n" + 
			"===================\r\n" + 
			"| Wood: "+wood+"        |\r\n" + 
			"| Stone: "+stone+"       |\r\n" + 
			"| Gold: "+gold+"        |\r\n" + 
			"| Money: "+money+"        |\r\n" + 
			"===================\r\n" + 
			"\r\n" + 
			"  Buy factory\r\n" + 
			"========================\r\n" + 
			"| No | Type            |\r\n" + 
			"========================\r\n" + 
			"| 1  | Wood factory    |\r\n" + 
			"| 2  | Stone factory   |\r\n" + 
			"| 3  | Gold factory    |\r\n" + 
			"========================\r\n" + 
			"To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.\r\n" + 
			"\r\n" + 
			"Choose factory [1-3], [0] to go back: ");
	int choice3 = sc.nextInt();
	if (wood >= 10 && stone >= 10 && gold >= 10) {
		
	}
	else {
		System.out.println("You dont have enough resources.\n");
		System.out.println("Press ENTER to continue\n");
		sc.nextLine();
	}
	switch (choice3) {
	case 1:
		Util.cls();
		boolean amogus = false;
		boolean valid1 = false;
		while (!amogus) {
		System.out.print("Input factory detail\r\n" + 
				"=========================\r\n" + 
				"Input factory name [5 - 15 characters] (inclusive): ");
		String facName = sc.nextLine();
		sc.nextLine();
		System.out.println("Press ENTER to continue...");
		if (facName.length()>4 && facName.length() < 16) {
			while (!valid1) {
				System.out.print("Input wood type [Teak | Mahogany | Oak] (case sensitive): ");
				String wName = sc.nextLine();
				sc.nextLine();
				System.out.println("Press ENTER to continue...");
				if (wName.equals("Teak") || wName.equals("Mahogany") || wName.equals("Oak")) {
					wood -= 10;
					stone -= 10;
					gold -= 10;
					factoryList.add(new Factory(facName, "Wood", 3, wName));
					System.out.println("Successfully bought a new factory!\n");
					System.out.println("Press ENTER to continue...");
					sc.nextLine();
					valid1 = true;
					amogus = true;
					Util.cls();
				}
				else {
					System.out.println("Wood type must be Teak, Mahogany, or Oak (case sensitive)!\n");
				}
			}
		}
		else {
			System.out.println("Factory name must be 5-15 characters (inclusive)!");
		}
		}
		break;
	case 2:
		Util.cls();
		boolean amogus2 = false;
		boolean valid12 = false;
		while (!amogus2) {
		System.out.print("Input factory detail\r\n" + 
				"=========================\r\n" + 
				"Input factory name [5 - 15 characters] (inclusive): ");
		String facName2 = sc.nextLine();
		sc.nextLine();
		System.out.println("Press ENTER to continue...");
		if (facName2.length()>4 && facName2.length() < 16) {
			while (!valid12) {
				System.out.print("Input stone type [Granite | Marble | Limestone] (case sensitive): ");
				String stoneName = sc.nextLine();
				sc.nextLine();
				System.out.println("Press ENTER to continue...");
				if (stoneName.equals("Granite") || stoneName.equals("Marble") || stoneName.equals("Limestone")) {
					wood -= 10;
					stone -= 10;
					gold -= 10;
					factoryList.add(new Factory(facName2, "Stone", 3, stoneName));
					System.out.println("Successfully bought a new factory!\n");
					System.out.println("Press ENTER to continue...");
					sc.nextLine();
					valid12 = true;
					amogus2 = true;
					Util.cls();
				}
				else {
					System.out.println("Stone type must be Granite, Marble, or Limestone (case sensitive)!\n");
				}
			}
		}
		else {
			System.out.println("Factory name must be 5-15 characters (inclusive)!");
		}
		}
		break;
	case 3:
		Util.cls();
		boolean amogus3 = false;
		boolean valid13 = false;
		while (!amogus3) {
		System.out.print("Input factory detail\r\n" + 
				"=========================\r\n" + 
				"Input factory name [5 - 15 characters] (inclusive): ");
		String facName3 = sc.nextLine();
		sc.nextLine();
		System.out.println("Press ENTER to continue...");
		if (facName3.length()>=5 && facName3.length() <= 15) {
			while (!valid13) {
				System.out.print("Input gold purity [18 - 24] (inclusive): ");
				String goldPur = sc.nextLine();
				sc.nextLine();
				System.out.println("Press ENTER to continue...");
				if (goldPur == "18" || goldPur == "19" || goldPur == "20" || goldPur == "21" || goldPur == "22" || goldPur == "23" || goldPur == "24") {
					wood -= 10;
					stone -= 10;
					gold -= 10;
					factoryList.add(new Factory(facName3, "Gold", 3, goldPur));
					System.out.println("Successfully bought a new factory!\n");
					System.out.println("Press ENTER to continue...");
					sc.nextLine();
					valid13 = true;
					amogus3 = true;
					Util.cls();
				}
				else {
					System.out.println("Gold purity must be between 18 - 24 (inclusive)!\n");
				}
			}
		}
		else {
			System.out.println("Factory name must be 5-15 characters (inclusive)!");
		}
		}
		break;
	default:
		break;
	}
}

private void viewFac() {
	System.out.println("============================================================================\r\n" + 
			"| Name             | Type       | Production Value | Special Attribute     |\r\n" + 
			"============================================================================\r\n" + 
			"| sikma            | Wood       | 3                | Wood type: Teak       |\r\n" + 
			"| ilham            | Stone      | 3                | Stone type: Granite   |\r\n" + 
			"| ikjahnm          | Stone      | 3                | Stone type: Marble    |\r\n" + 
			"| agdida           | Gold       | 3                | Gold purity: 18       |\r\n" + 
			"============================================================================\r\n" + 
			"\r\n" + 
			"Press enter to continue...");
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
