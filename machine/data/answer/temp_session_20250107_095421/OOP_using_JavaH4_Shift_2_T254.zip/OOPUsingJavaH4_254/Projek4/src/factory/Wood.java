package factory;

public class Wood extends Factory{
	private String wood;
	

	public Wood(String factoryName, String wood) {
		super(factoryName);
		this.wood = wood;
	}

	public String getWood() {
		return wood;
	}

	public void setWood(String wood) {
		this.wood = wood;
	}
	
	public void displayInfoWood() {
		super.displayInfo();
		System.out.printf(" Wood\t| Wood type: "+wood+"\t|");
	}

}
