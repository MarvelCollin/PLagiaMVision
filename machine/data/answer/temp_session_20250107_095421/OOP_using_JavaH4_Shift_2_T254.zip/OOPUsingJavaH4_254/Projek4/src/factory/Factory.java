package factory;

public class Factory {
	private String factoryName;

	public Factory(String factoryName) {
		super();
		this.factoryName = factoryName;
	}

	public String getFactoryName() {
		return factoryName;
	}

	public void setFactoryName(String factoryName) {
		this.factoryName = factoryName;
	}
	public void displayInfo() {
		System.out.printf("| " + factoryName + "\t\t\t|");
	}
	

}
