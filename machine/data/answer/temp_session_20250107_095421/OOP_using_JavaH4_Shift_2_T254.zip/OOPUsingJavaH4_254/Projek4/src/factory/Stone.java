package factory;

public class Stone extends Factory{
	private String material;

	public Stone(String factoryName, String material) {
		super(factoryName);
		this.material = material;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}
	public void displayInfoStone() {
		super.displayInfo();
		System.out.printf(" Stone\t| Stone type: "+material+"\t|");
	}
	

}
