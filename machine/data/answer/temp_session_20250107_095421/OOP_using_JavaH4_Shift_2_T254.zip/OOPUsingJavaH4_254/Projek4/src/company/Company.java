package company;

import java.util.ArrayList;

import factory.Factory;
import factory.Gold;
import factory.Stone;
import factory.Wood;



public class Company {
	
	
	private String company;
	ArrayList<Factory> factories = new ArrayList<>();
	public Company(String company) {
		super();
		this.company = company;
	}
	
	public void addFactory(Factory factory) {
		factories.add(factory);
	}
	public void showAll() {
		for(Factory factore : factories) {
			factore.displayInfo();
		}
	}
	
	
	
}
