package main;

import java.util.Scanner;

import company.Company;
import factory.Gold;
import factory.Stone;
import factory.Wood;

public class Main {
	Scanner scan = new Scanner(System.in);
	public Main() {
		int op = 0;
		int op2 = -1;
		int op3 = -1;
		int woods = 40;
		int Stones = 40;
		int Golds = 40;
		int day = 1;
		int money = 0;
		Company  company = new Company("MyCompany");
		while(true) {
			
			System.out.println(" /\\  /\\/\\  /\\/ __\\_ _  ___| |_ ___  _ __ _   _\r\n" + 
						" / /_/ / /_/ / _\\/ _` |/ __| __/ _ \\| '__| | | |\r\n" + 
						"/ __  / __  / / | (_| | (__| || (_) | |  | |_| |\r\n" + 
						"\\/ /_/\\/ /_/\\/   \\__,_|\\___|\\__\\___/|_|   \\__, |\r\n" + 
						"                                          |___/\r\n" + 
						"\r\n" + 
						"1. Play game\r\n" + 
						"2. Exit");
			System.out.printf(">>");
				op = scan.nextInt();
					if(op==1) {
						while(op2 < 1 || op2 > 5) {
							System.out.println("Day: " + day);
							System.out.printf("===================\r\n" + 
									"| Your resources  |\r\n" + 
									"===================\r\n" + 
									"| Wood: %d\t|\r\n" + 
									"| Stone: %d\t|\r\n" + 
									"| Gold: %d\t|\r\n" + 
									"| Money: %d\t|\r\n" + 
									"===================\n", woods, Stones, Golds, money);
							System.out.println("Actions:\r\n" + 
									"1. Finish day\r\n" + 
									"2. Buy factory\r\n" + 
									"3. View all factory\r\n" + 
									"4. Trade center\r\n" + 
									"5. Exit game\r\n" + 
									"\r\n" + 
									"Choose action [1-5]:");
							op2 = scan.nextInt();
							if(op2==1) {
								day++;
							}
							
							if(op2==2) {
								
								while(op3 < 1 || op3 > 3) {
									System.out.printf("===================\r\n" + 
											"| Your resources  |\r\n" + 
											"===================\r\n" + 
											"| Wood: %d\t|\r\n" + 
											"| Stone: %d\t|\r\n" + 
											"| Gold: %d\t|\r\n" + 
											"| Money: %d\t|\r\n" + 
											"===================\n", woods, Stones, Golds, money);
									
									System.out.println("Buy factory");
									System.out.println("Buy factory\r\n" + 
											"========================\r\n" + 
											"| No | Type            |\r\n" + 
											"========================\r\n" + 
											"| 1  | Wood factory    |\r\n" + 
											"| 2  | Stone factory   |\r\n" + 
											"| 3  | Gold factory    |\r\n" + 
											"========================\r\n" + 
											"To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.\r\n" + 
											"\r\n" + 
											"Choose factory [1-3], [0] to go back:");
									op3 = scan.nextInt();
									if(op3 == 1) {
										String tempName;
										String tempName1=null;
										System.out.println("Input factory detail\r\n" + 
												"=========================\r\n" + 
												"Input factory name [5 - 15 characters] (inclusive):");
										scan.nextLine();
										tempName = scan.nextLine();
										
										System.out.println("Input wood type [Teak | Mahogany | Oak] (case sensitive):");
										while(tempName1 != "Teak" || tempName1 != "Mahogany" || tempName1 != "Oak") {
											tempName1 = scan.nextLine();
										}
										Wood facto = new Wood(tempName, tempName1);
										company.addFactory(facto);
										woods -= 10;
										Stones -=10;
										Golds -= 10;
										System.out.println("Succesfully purchase a factory");
										scan.nextLine();
									}
									if(op3 == 2) {
										String tempName;
										String tempName1=null;
										System.out.println("Input factory detail\r\n" + 
												"=========================\r\n" + 
												"Input factory name [5 - 15 characters] (inclusive):");
										scan.nextLine();
										tempName = scan.nextLine();
										
										System.out.println("Input Stone type [Granite | Marble | Limestone] (case sensitive):");
										while(tempName1 != "Granite" || tempName1 != "Marble" || tempName1 != "Limestone") {
											tempName1 = scan.nextLine();
										}
										Stone facto = new  Stone(tempName, tempName1);
										company.addFactory(facto);
										woods -= 10;
										Stones -=10;
										Golds -= 10;
										System.out.println("Succesfully purchase a factory");
										scan.nextLine();
									}
									if(op3 == 3) {
										String tempName;
										int tempNum = 0;
										System.out.println("Input factory detail\r\n" + 
												"=========================\r\n" + 
												"Input factory name [5 - 15 characters] (inclusive):");
										scan.nextLine();
										tempName = scan.nextLine();
										
										System.out.println("Input gold purity [18 - 24] (inclusive):");
										while(tempNum <  18 || tempNum > 24) {
											tempNum = scan.nextInt();
										}
										Gold facto = new Gold(tempName, tempNum);
										company.addFactory(facto);
										System.out.println("Succesfully purchase a factory");
										woods -= 10;
										Stones -=10;
										Golds -= 10;
										scan.nextLine();
									}
								}
								
							}
							
							
							
							else if(op2==3) {
								System.out.println("============================================================================\r\n" + 
										"| Name             | Type       | Production Value | Special Attribute     |\r\n" + 
										"============================================================================");
								company.showAll();
								System.out.println("============================================================================");
								scan.nextLine();
								
							}
							else if(op2==4) {
								
							}
							else if(op2==5) {
								break;
							}
							
							
							
						}
					
						
						
						
						

						  
					}
					if(op==2) {
						System.exit(0);
					}	
				}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
