package factory;

public class Gold extends Factory{
	private int purity;

	public Gold(String factoryName, int purity) {
		super(factoryName);
		this.purity = purity;
	}

	public int getPurity() {
		return purity;
	}

	public void setPurity(int purity) {
		this.purity = purity;
	}
	public void displayInfoGold() {
		super.displayInfo();
		System.out.printf(" Gold\t\t\t| Gold Purity: "+purity+"\t\t\t|");
	}
	
	
	

}
