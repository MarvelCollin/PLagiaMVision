package main;

import java.util.Scanner;

public class Main {
	int a;
	int as;
	int day = 1;
	int pabrikkayu = 0;
	String namapabrikkayu;
	int pabrikbatu = 0;
	int pabrikemas = 0;
	int wood = 40;
	int stone = 40;
	int gold = 40;
	int Money;
	int ppp;
	int b;
	Scanner scan = new Scanner(System.in);
	public Main() {
		for(int i = 1; i < 1001; i++) System.out.println("");
		System.out.println("               ___          _");
	System.out.println("  /\\  /\\/\\  /\\/ __\\_ _  ___| |_ ___  _ __ _   _");
	System.out.println(" / /_/ / /_/ / _\\/ _` |/ __| __/ _ \\| '__| | | |");
	System.out.println("/ __  / __  / / | (_| | (__| || (_) | |  | |_| |");
	System.out.println("\\/ /_/\\/ /_/\\/   \\__,_|\\___|\\__\\___/|_|   \\__, |");
	System.out.println("                                          |___/");
	
	System.out.println("");
	System.out.println("1. Play game");
	System.out.println("2. Exit");
	System.out.print(">> ");
	a = scan.nextInt();
	
	if(a == 1)
	{
		while( b != 6) {
		for(int i = 1; i < 1001; i++) System.out.println("");
		System.out.println("Day "+ day);
		System.out.println("===================");
		System.out.println("| Your resources  |");
		System.out.println("===================");
		System.out.print("| Wood: "+ wood);
		for(int j = 0 ; j <= ppp; j++)
		{
			if(wood >= 10 && wood <= 100)
			{
				ppp = 7;
			} else 	if(wood >= 100 && wood <= 1000)
			{
				ppp = 6;
			}else 	if(wood >= 1000 && wood <= 10000)
			{
				ppp = 5;
			}else 	if(wood >= 10000 && wood <= 100000)
			{
				ppp = 4;
			}else 	if(wood >= 100000 && wood <= 1000000)
			{
				ppp = 3;
			}
			
			System.out.print(" ");
		}
		System.out.println("|");
		System.out.print("| Stone: "+ stone);
		for(int j = 0 ; j <= ppp; j++)
		{
			if(stone >= 10 && stone <= 100)
			{
				ppp = 6;
			} else 	if(stone >= 100 && stone <= 1000)
			{
				ppp = 5;
			}else 	if(stone >= 1000 && stone <= 10000)
			{
				ppp = 4;
			}else 	if(stone >= 10000 && stone <= 100000)
			{
				ppp = 3;
			}else 	if(stone >= 100000 && stone <= 1000000)
			{
				ppp = 2;
			}
			
			System.out.print(" ");
		}
		System.out.println("|");
		System.out.print("| Gold: "+ gold);
		for(int j = 0 ; j <= ppp; j++)
		{
			if(gold >= 10 && gold <= 100)
			{
				ppp = 7;
			} else 	if(gold >= 100 && gold <= 1000)
			{
				ppp = 6;
			}else 	if(gold >= 1000 && gold <= 10000)
			{
				ppp = 5;
			}else 	if(gold >= 10000 && gold <= 100000)
			{
				ppp = 4;
			}else 	if(gold >= 100000 && gold <= 1000000)
			{
				ppp = 3;
			}
			
			System.out.print(" ");
		}
		System.out.println("|");
		System.out.print("| Money: "+ Money );
		for(int j = 0 ; j <= ppp; j++)
		{
			if(Money >= 10 && Money <= 100)
			{
				ppp = 6;
			} else 	if(Money >= 100 && Money <= 1000)
			{
				ppp = 5;
			}else 	if(Money >= 1000 && Money <= 10000)
			{
				ppp = 4;
			}else 	if(Money >= 10000 && Money <= 100000)
			{
				ppp = 3;
			}else 	if(Money >= 100000 && Money <= 1000000)
			{
				ppp = 2;
			} else if(Money <= 10)
			{
				ppp = 7;
			}
			
			System.out.print(" ");
		}
		System.out.println("|");
		System.out.println("===================");
		System.out.println("");
		System.out.println("Action:");
		System.out.println("1. Finish day");
		System.out.println("2. Buy factory");
		System.out.println("3. View all Factory");
		System.out.println("4. Trade center");
		System.out.println("5. Exit game");
		System.out.print(">> ");
		b = scan.nextInt();
		if(b == 1)
		{
			System.out.println("Going to next day....");
			System.out.println("");
			System.out.println("Press A to continue");
			String ab = scan.next();
			if(ab == "A" || ab == "a")
			{
				day = day +1;
				
			}else if(ab != "A" || ab != "a")
			{
				day = day +1;
				
			}
		} else if (b == 2)
		{
			for(int i = 1; i < 1001; i++) System.out.println("");
			System.out.println("===================");
			System.out.println("| Your resources  |");
			System.out.println("===================");
			System.out.print("| Wood: "+ wood);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(wood >= 10 && wood <= 100)
				{
					ppp = 7;
				} else 	if(wood >= 100 && wood <= 1000)
				{
					ppp = 6;
				}else 	if(wood >= 1000 && wood <= 10000)
				{
					ppp = 5;
				}else 	if(wood >= 10000 && wood <= 100000)
				{
					ppp = 4;
				}else 	if(wood >= 100000 && wood <= 1000000)
				{
					ppp = 3;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Stone: "+ stone);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(stone >= 10 && stone <= 100)
				{
					ppp = 6;
				} else 	if(stone >= 100 && stone <= 1000)
				{
					ppp = 5;
				}else 	if(stone >= 1000 && stone <= 10000)
				{
					ppp = 4;
				}else 	if(stone >= 10000 && stone <= 100000)
				{
					ppp = 3;
				}else 	if(stone >= 100000 && stone <= 1000000)
				{
					ppp = 2;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Gold: "+ gold);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(gold >= 10 && gold <= 100)
				{
					ppp = 7;
				} else 	if(gold >= 100 && gold <= 1000)
				{
					ppp = 6;
				}else 	if(gold >= 1000 && gold <= 10000)
				{
					ppp = 5;
				}else 	if(gold >= 10000 && gold <= 100000)
				{
					ppp = 4;
				}else 	if(gold >= 100000 && gold <= 1000000)
				{
					ppp = 3;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Money: "+ Money );
			for(int j = 0 ; j <= ppp; j++)
			{
				if(Money >= 10 && Money <= 100)
				{
					ppp = 6;
				} else 	if(Money >= 100 && Money <= 1000)
				{
					ppp = 5;
				}else 	if(Money >= 1000 && Money <= 10000)
				{
					ppp = 4;
				}else 	if(Money >= 10000 && Money <= 100000)
				{
					ppp = 3;
				}else 	if(Money >= 100000 && Money <= 1000000)
				{
					ppp = 2;
				} else if(Money <= 10)
				{
					ppp = 7;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.println("===================");
			System.out.println("");
			System.out.println("  Buy factory");
			System.out.println("========================");
			System.out.println("| No | Type            |");
			System.out.println("========================");
			System.out.println("| 1  | Wood factory    |");
			System.out.println("| 2  | Stone factory   |");
			System.out.println("| 3  | Gold factory    |");
			System.out.println("========================");
			System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
			System.out.println("");
			System.out.print("Choose factory [1-3], [0] to go back: ");
			int zzz = scan.nextInt();
			if(zzz == 1)
			{
				for(int i = 1; i < 1001; i++) System.out.println("");
				pabrikkayu++;
				System.out.println("Input factory detail");
				System.out.println("=========================");
				for(int j = 0; j < j+1; j++)
				{
				System.out.print("Input factory name[5-15 characters](inclusive): ");
				String namapabrikkayu = scan.nextLine();
				if(namapabrikkayu.length()<=4 || namapabrikkayu.length() >=16)
				{
					System.out.println("Factory name must be 5-15 characters (inclusive)!");
				} else if(namapabrikkayu.length()>=5 && namapabrikkayu.length() <= 15)
				{
					break;
				}
				}
				for(int j = 0; j < j+1; j++)
				{
				System.out.print("Input wood type [Teak | Mahoraga | Oak](case sensitive): ");
				String namapabrikkayu = scan.nextLine();
				if(namapabrikkayu != "Teak" || namapabrikkayu != "Mahoraga" || namapabrikkayu != "Oak")
				{
					System.out.println("Wood Type must be [Teak | Mahoraga | Oak](case sensitive)!");
				} else if(namapabrikkayu == "Teak" || namapabrikkayu == "Mahoraga" || namapabrikkayu == "Oak")
				{
					break;
				}
				}
				System.out.println("Successfully bought a new factory");
				System.out.println("");
				System.out.println("Press A to continue");
				String ab = scan.next();
				if(ab == "A" || ab == "a")
				{
				}else if(ab != "A" || ab != "a")
				{
				}
			} else if (zzz == 2)
			{
				for(int i = 1; i < 1001; i++) System.out.println("");
				pabrikbatu++;
			} else if(zzz == 3)
			{
				for(int i = 1; i < 1001; i++) System.out.println("");
				pabrikemas++;
			} else if (zzz == 0)
			{
				
			} else if (zzz >= 4 || zzz <= -1)
			{
				while (zzz >= 4 || zzz <= -1)
				{
					System.out.println("===================");
					System.out.println("| Your resources  |");
					System.out.println("===================");
					System.out.print("| Wood: "+ wood);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(wood >= 10 && wood <= 100)
						{
							ppp = 7;
						} else 	if(wood >= 100 && wood <= 1000)
						{
							ppp = 6;
						}else 	if(wood >= 1000 && wood <= 10000)
						{
							ppp = 5;
						}else 	if(wood >= 10000 && wood <= 100000)
						{
							ppp = 4;
						}else 	if(wood >= 100000 && wood <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Stone: "+ stone);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(stone >= 10 && stone <= 100)
						{
							ppp = 6;
						} else 	if(stone >= 100 && stone <= 1000)
						{
							ppp = 5;
						}else 	if(stone >= 1000 && stone <= 10000)
						{
							ppp = 4;
						}else 	if(stone >= 10000 && stone <= 100000)
						{
							ppp = 3;
						}else 	if(stone >= 100000 && stone <= 1000000)
						{
							ppp = 2;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Gold: "+ gold);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(gold >= 10 && gold <= 100)
						{
							ppp = 7;
						} else 	if(gold >= 100 && gold <= 1000)
						{
							ppp = 6;
						}else 	if(gold >= 1000 && gold <= 10000)
						{
							ppp = 5;
						}else 	if(gold >= 10000 && gold <= 100000)
						{
							ppp = 4;
						}else 	if(gold >= 100000 && gold <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Money: "+ Money );
					for(int j = 0 ; j <= ppp; j++)
					{
						if(Money >= 10 && Money <= 100)
						{
							ppp = 6;
						} else 	if(Money >= 100 && Money <= 1000)
						{
							ppp = 5;
						}else 	if(Money >= 1000 && Money <= 10000)
						{
							ppp = 4;
						}else 	if(Money >= 10000 && Money <= 100000)
						{
							ppp = 3;
						}else 	if(Money >= 100000 && Money <= 1000000)
						{
							ppp = 2;
						} else if(Money <= 10)
						{
							ppp = 7;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.println("===================");
					System.out.println("");
					System.out.println("  Buy factory");
					System.out.println("========================");
					System.out.println("| No | Type            |");
					System.out.println("========================");
					System.out.println("| 1  | Wood factory    |");
					System.out.println("| 2  | Stone factory   |");
					System.out.println("| 3  | Gold factory    |");
					System.out.println("========================");
					System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
					System.out.println("");
					System.out.print("Choose factory [1-3], [0] to go back: ");
					as = scan.nextInt();
					if (as >= 0 && as <= 3)
					{
						zzz = 1;
					}
				}if(as == 1)
				{
					
				} else if (as == 2)
				{
					
				} else if(as == 3)
				{
					
				} else if (as == 0)
				{
					day = 0;
					new Main();
				}
			}
		}else if (b == 3)
		{
			for(int i = 1; i < 1001; i++) System.out.println("");
			if(pabrikkayu == 0 || pabrikbatu == 0 || pabrikemas == 0)
			{
				System.out.println("You don't own a single factory");
				System.out.println("");
				System.out.println("Press A to continue");
				String ab = scan.next();
				if(ab == "A" || ab == "a")
				{
					
				} else if(ab != "A" || ab != "a")
				{
					
				}
			}
		}else if (b == 4)
		{
			
		}else if (b == 5)
		{
			for(int i = 1; i < 1001; i++) System.out.println("");
			System.out.println("Game Over");
			System.out.println("================");
			System.out.println("Final Score: " + Money);
			System.out.println();
			System.out.println("Press A to continue");
			String ab = scan.next();
			if(ab == "A" || ab == "a")
			{
				new Main();
			} else if(ab != "A" || ab != "a")
			{
				new Main();
			}
		}else if (b <= 0 || b >= 6)
		{
			for(int i = 1; i < 1001; i++) System.out.println("");
			System.out.println("Day "+ day);
			System.out.println("===================");
			System.out.println("| Your resources  |");
			System.out.println("===================");
			System.out.print("| Wood: "+ wood);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(wood >= 10 && wood <= 100)
				{
					ppp = 7;
				} else 	if(wood >= 100 && wood <= 1000)
				{
					ppp = 6;
				}else 	if(wood >= 1000 && wood <= 10000)
				{
					ppp = 5;
				}else 	if(wood >= 10000 && wood <= 100000)
				{
					ppp = 4;
				}else 	if(wood >= 100000 && wood <= 1000000)
				{
					ppp = 3;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Stone: "+ stone);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(stone >= 10 && stone <= 100)
				{
					ppp = 6;
				} else 	if(stone >= 100 && stone <= 1000)
				{
					ppp = 5;
				}else 	if(stone >= 1000 && stone <= 10000)
				{
					ppp = 4;
				}else 	if(stone >= 10000 && stone <= 100000)
				{
					ppp = 3;
				}else 	if(stone >= 100000 && stone <= 1000000)
				{
					ppp = 2;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Gold: "+ gold);
			for(int j = 0 ; j <= ppp; j++)
			{
				if(gold >= 10 && gold <= 100)
				{
					ppp = 7;
				} else 	if(gold >= 100 && gold <= 1000)
				{
					ppp = 6;
				}else 	if(gold >= 1000 && gold <= 10000)
				{
					ppp = 5;
				}else 	if(gold >= 10000 && gold <= 100000)
				{
					ppp = 4;
				}else 	if(gold >= 100000 && gold <= 1000000)
				{
					ppp = 3;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.print("| Money: "+ Money );
			for(int j = 0 ; j <= ppp; j++)
			{
				if(Money >= 10 && Money <= 100)
				{
					ppp = 6;
				} else 	if(Money >= 100 && Money <= 1000)
				{
					ppp = 5;
				}else 	if(Money >= 1000 && Money <= 10000)
				{
					ppp = 4;
				}else 	if(Money >= 10000 && Money <= 100000)
				{
					ppp = 3;
				}else 	if(Money >= 100000 && Money <= 1000000)
				{
					ppp = 2;
				} else if(Money <= 10)
				{
					ppp = 7;
				}
				
				System.out.print(" ");
			}
			System.out.println("|");
			System.out.println("===================");
			System.out.println("");
			System.out.println("Action:");
			System.out.println("1. Finish day");
			System.out.println("2. Buy factory");
			System.out.println("3. View all Factory");
			System.out.println("4. Trade center");
			System.out.println("5. Exit game");
			System.out.print(">> ");
			b = scan.nextInt();
			while(b <= 0 || b >= 6)
			{
				if(b == 1)
				{
					System.out.println("Going to next day....");
					System.out.println("");
					System.out.println("Press A to continue");
					String ab = scan.next();
					if(ab == "A" || ab == "a")
					{
						day = day +1;
						
					}else if(ab != "A" || ab != "a")
					{
						day = day +1;
						
					}
				} else if (b == 2)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					System.out.println("===================");
					System.out.println("| Your resources  |");
					System.out.println("===================");
					System.out.print("| Wood: "+ wood);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(wood >= 10 && wood <= 100)
						{
							ppp = 7;
						} else 	if(wood >= 100 && wood <= 1000)
						{
							ppp = 6;
						}else 	if(wood >= 1000 && wood <= 10000)
						{
							ppp = 5;
						}else 	if(wood >= 10000 && wood <= 100000)
						{
							ppp = 4;
						}else 	if(wood >= 100000 && wood <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Stone: "+ stone);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(stone >= 10 && stone <= 100)
						{
							ppp = 6;
						} else 	if(stone >= 100 && stone <= 1000)
						{
							ppp = 5;
						}else 	if(stone >= 1000 && stone <= 10000)
						{
							ppp = 4;
						}else 	if(stone >= 10000 && stone <= 100000)
						{
							ppp = 3;
						}else 	if(stone >= 100000 && stone <= 1000000)
						{
							ppp = 2;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Gold: "+ gold);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(gold >= 10 && gold <= 100)
						{
							ppp = 7;
						} else 	if(gold >= 100 && gold <= 1000)
						{
							ppp = 6;
						}else 	if(gold >= 1000 && gold <= 10000)
						{
							ppp = 5;
						}else 	if(gold >= 10000 && gold <= 100000)
						{
							ppp = 4;
						}else 	if(gold >= 100000 && gold <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Money: "+ Money );
					for(int j = 0 ; j <= ppp; j++)
					{
						if(Money >= 10 && Money <= 100)
						{
							ppp = 6;
						} else 	if(Money >= 100 && Money <= 1000)
						{
							ppp = 5;
						}else 	if(Money >= 1000 && Money <= 10000)
						{
							ppp = 4;
						}else 	if(Money >= 10000 && Money <= 100000)
						{
							ppp = 3;
						}else 	if(Money >= 100000 && Money <= 1000000)
						{
							ppp = 2;
						} else if(Money <= 10)
						{
							ppp = 7;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.println("===================");
					System.out.println("");
					System.out.println("  Buy factory");
					System.out.println("========================");
					System.out.println("| No | Type            |");
					System.out.println("========================");
					System.out.println("| 1  | Wood factory    |");
					System.out.println("| 2  | Stone factory   |");
					System.out.println("| 3  | Gold factory    |");
					System.out.println("========================");
					System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
					System.out.println("");
					System.out.print("Choose factory [1-3], [0] to go back: ");
					int zzz = scan.nextInt();
					if(zzz == 1)
					{
						
					} else if (zzz == 2)
					{
						
					} else if(zzz == 3)
					{
						
					} else if (zzz == 0)
					{
						
					} else if (zzz >= 4 || zzz <= -1)
					{
						while (zzz >= 4 || zzz <= -1)
						{
							System.out.println("===================");
							System.out.println("| Your resources  |");
							System.out.println("===================");
							System.out.print("| Wood: "+ wood);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(wood >= 10 && wood <= 100)
								{
									ppp = 7;
								} else 	if(wood >= 100 && wood <= 1000)
								{
									ppp = 6;
								}else 	if(wood >= 1000 && wood <= 10000)
								{
									ppp = 5;
								}else 	if(wood >= 10000 && wood <= 100000)
								{
									ppp = 4;
								}else 	if(wood >= 100000 && wood <= 1000000)
								{
									ppp = 3;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Stone: "+ stone);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(stone >= 10 && stone <= 100)
								{
									ppp = 6;
								} else 	if(stone >= 100 && stone <= 1000)
								{
									ppp = 5;
								}else 	if(stone >= 1000 && stone <= 10000)
								{
									ppp = 4;
								}else 	if(stone >= 10000 && stone <= 100000)
								{
									ppp = 3;
								}else 	if(stone >= 100000 && stone <= 1000000)
								{
									ppp = 2;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Gold: "+ gold);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(gold >= 10 && gold <= 100)
								{
									ppp = 7;
								} else 	if(gold >= 100 && gold <= 1000)
								{
									ppp = 6;
								}else 	if(gold >= 1000 && gold <= 10000)
								{
									ppp = 5;
								}else 	if(gold >= 10000 && gold <= 100000)
								{
									ppp = 4;
								}else 	if(gold >= 100000 && gold <= 1000000)
								{
									ppp = 3;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Money: "+ Money );
							for(int j = 0 ; j <= ppp; j++)
							{
								if(Money >= 10 && Money <= 100)
								{
									ppp = 6;
								} else 	if(Money >= 100 && Money <= 1000)
								{
									ppp = 5;
								}else 	if(Money >= 1000 && Money <= 10000)
								{
									ppp = 4;
								}else 	if(Money >= 10000 && Money <= 100000)
								{
									ppp = 3;
								}else 	if(Money >= 100000 && Money <= 1000000)
								{
									ppp = 2;
								} else if(Money <= 10)
								{
									ppp = 7;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.println("===================");
							System.out.println("");
							System.out.println("  Buy factory");
							System.out.println("========================");
							System.out.println("| No | Type            |");
							System.out.println("========================");
							System.out.println("| 1  | Wood factory    |");
							System.out.println("| 2  | Stone factory   |");
							System.out.println("| 3  | Gold factory    |");
							System.out.println("========================");
							System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
							System.out.println("");
							System.out.print("Choose factory [1-3], [0] to go back: ");
							as = scan.nextInt();
							if (as >= 0 && as <= 3)
							{
								zzz = 1;
							}
						}if(as == 1)
						{
							
						} else if (as == 2)
						{
							
						} else if(as == 3)
						{
							
						} else if (as == 0)
						{
							day = 0;
							new Main();
						}
					}
				}else if (b == 3)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					if(pabrikkayu == 0 || pabrikbatu == 0 || pabrikemas == 0)
					{
						System.out.println("You don't own a single factory");
						System.out.println("");
						System.out.println("Press A to continue");
						String ab = scan.next();
						if(ab == "A" || ab == "a")
						{
							
						} else if(ab != "A" || ab != "a")
						{
							
						}
					}
				}else if (b == 4)
				{
					
				}else if (b == 5)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					System.out.println("Game Over");
					System.out.println("================");
					System.out.println("Final Score: " + Money);
					System.out.println();
					System.out.println("Press A to continue");
					String ab = scan.next();
					if(ab == "A" || ab == "a")
					{
						new Main();
					}else if(ab != "A" || ab != "a")
					{
						new Main();
					}
				}else if (b <= 0 || b >= 6)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					System.out.println("Day "+ day);
					System.out.println("===================");
					System.out.println("| Your resources  |");
					System.out.println("===================");
					System.out.print("| Wood: "+ wood);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(wood >= 10 && wood <= 100)
						{
							ppp = 7;
						} else 	if(wood >= 100 && wood <= 1000)
						{
							ppp = 6;
						}else 	if(wood >= 1000 && wood <= 10000)
						{
							ppp = 5;
						}else 	if(wood >= 10000 && wood <= 100000)
						{
							ppp = 4;
						}else 	if(wood >= 100000 && wood <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Stone: "+ stone);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(stone >= 10 && stone <= 100)
						{
							ppp = 6;
						} else 	if(stone >= 100 && stone <= 1000)
						{
							ppp = 5;
						}else 	if(stone >= 1000 && stone <= 10000)
						{
							ppp = 4;
						}else 	if(stone >= 10000 && stone <= 100000)
						{
							ppp = 3;
						}else 	if(stone >= 100000 && stone <= 1000000)
						{
							ppp = 2;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Gold: "+ gold);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(gold >= 10 && gold <= 100)
						{
							ppp = 7;
						} else 	if(gold >= 100 && gold <= 1000)
						{
							ppp = 6;
						}else 	if(gold >= 1000 && gold <= 10000)
						{
							ppp = 5;
						}else 	if(gold >= 10000 && gold <= 100000)
						{
							ppp = 4;
						}else 	if(gold >= 100000 && gold <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Money: "+ Money );
					for(int j = 0 ; j <= ppp; j++)
					{
						if(Money >= 10 && Money <= 100)
						{
							ppp = 6;
						} else 	if(Money >= 100 && Money <= 1000)
						{
							ppp = 5;
						}else 	if(Money >= 1000 && Money <= 10000)
						{
							ppp = 4;
						}else 	if(Money >= 10000 && Money <= 100000)
						{
							ppp = 3;
						}else 	if(Money >= 100000 && Money <= 1000000)
						{
							ppp = 2;
						} else if(Money <= 10)
						{
							ppp = 7;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.println("===================");
					System.out.println("");
					System.out.println("Action:");
					System.out.println("1. Finish day");
					System.out.println("2. Buy factory");
					System.out.println("3. View all Factory");
					System.out.println("4. Trade center");
					System.out.println("5. Exit game");
					System.out.print(">> ");
					b = scan.nextInt();
				}
				if(b == 1)
				{
					System.out.println("Going to next day....");
					System.out.println("");
					System.out.println("Press A to continue");
					String ab = scan.next();
					if(ab == "A" || ab == "a")
					{
						day = day +1;
						
					}else if(ab != "A" || ab != "a")
					{
						day = day +1;
						
					}
				} else if (b == 2)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					System.out.println("===================");
					System.out.println("| Your resources  |");
					System.out.println("===================");
					System.out.print("| Wood: "+ wood);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(wood >= 10 && wood <= 100)
						{
							ppp = 7;
						} else 	if(wood >= 100 && wood <= 1000)
						{
							ppp = 6;
						}else 	if(wood >= 1000 && wood <= 10000)
						{
							ppp = 5;
						}else 	if(wood >= 10000 && wood <= 100000)
						{
							ppp = 4;
						}else 	if(wood >= 100000 && wood <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Stone: "+ stone);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(stone >= 10 && stone <= 100)
						{
							ppp = 6;
						} else 	if(stone >= 100 && stone <= 1000)
						{
							ppp = 5;
						}else 	if(stone >= 1000 && stone <= 10000)
						{
							ppp = 4;
						}else 	if(stone >= 10000 && stone <= 100000)
						{
							ppp = 3;
						}else 	if(stone >= 100000 && stone <= 1000000)
						{
							ppp = 2;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Gold: "+ gold);
					for(int j = 0 ; j <= ppp; j++)
					{
						if(gold >= 10 && gold <= 100)
						{
							ppp = 7;
						} else 	if(gold >= 100 && gold <= 1000)
						{
							ppp = 6;
						}else 	if(gold >= 1000 && gold <= 10000)
						{
							ppp = 5;
						}else 	if(gold >= 10000 && gold <= 100000)
						{
							ppp = 4;
						}else 	if(gold >= 100000 && gold <= 1000000)
						{
							ppp = 3;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.print("| Money: "+ Money );
					for(int j = 0 ; j <= ppp; j++)
					{
						if(Money >= 10 && Money <= 100)
						{
							ppp = 6;
						} else 	if(Money >= 100 && Money <= 1000)
						{
							ppp = 5;
						}else 	if(Money >= 1000 && Money <= 10000)
						{
							ppp = 4;
						}else 	if(Money >= 10000 && Money <= 100000)
						{
							ppp = 3;
						}else 	if(Money >= 100000 && Money <= 1000000)
						{
							ppp = 2;
						} else if(Money <= 10)
						{
							ppp = 7;
						}
						
						System.out.print(" ");
					}
					System.out.println("|");
					System.out.println("===================");
					System.out.println("");
					System.out.println("  Buy factory");
					System.out.println("========================");
					System.out.println("| No | Type            |");
					System.out.println("========================");
					System.out.println("| 1  | Wood factory    |");
					System.out.println("| 2  | Stone factory   |");
					System.out.println("| 3  | Gold factory    |");
					System.out.println("========================");
					System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
					System.out.println("");
					System.out.print("Choose factory [1-3], [0] to go back: ");
					int zzz = scan.nextInt();
					if(zzz == 1)
					{
						
					} else if (zzz == 2)
					{
						
					} else if(zzz == 3)
					{
						
					} else if (zzz == 0)
					{
						
					} else if (zzz >= 4 || zzz <= -1)
					{
						while (zzz >= 4 || zzz <= -1)
						{
							System.out.println("===================");
							System.out.println("| Your resources  |");
							System.out.println("===================");
							System.out.print("| Wood: "+ wood);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(wood >= 10 && wood <= 100)
								{
									ppp = 7;
								} else 	if(wood >= 100 && wood <= 1000)
								{
									ppp = 6;
								}else 	if(wood >= 1000 && wood <= 10000)
								{
									ppp = 5;
								}else 	if(wood >= 10000 && wood <= 100000)
								{
									ppp = 4;
								}else 	if(wood >= 100000 && wood <= 1000000)
								{
									ppp = 3;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Stone: "+ stone);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(stone >= 10 && stone <= 100)
								{
									ppp = 6;
								} else 	if(stone >= 100 && stone <= 1000)
								{
									ppp = 5;
								}else 	if(stone >= 1000 && stone <= 10000)
								{
									ppp = 4;
								}else 	if(stone >= 10000 && stone <= 100000)
								{
									ppp = 3;
								}else 	if(stone >= 100000 && stone <= 1000000)
								{
									ppp = 2;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Gold: "+ gold);
							for(int j = 0 ; j <= ppp; j++)
							{
								if(gold >= 10 && gold <= 100)
								{
									ppp = 7;
								} else 	if(gold >= 100 && gold <= 1000)
								{
									ppp = 6;
								}else 	if(gold >= 1000 && gold <= 10000)
								{
									ppp = 5;
								}else 	if(gold >= 10000 && gold <= 100000)
								{
									ppp = 4;
								}else 	if(gold >= 100000 && gold <= 1000000)
								{
									ppp = 3;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.print("| Money: "+ Money );
							for(int j = 0 ; j <= ppp; j++)
							{
								if(Money >= 10 && Money <= 100)
								{
									ppp = 6;
								} else 	if(Money >= 100 && Money <= 1000)
								{
									ppp = 5;
								}else 	if(Money >= 1000 && Money <= 10000)
								{
									ppp = 4;
								}else 	if(Money >= 10000 && Money <= 100000)
								{
									ppp = 3;
								}else 	if(Money >= 100000 && Money <= 1000000)
								{
									ppp = 2;
								} else if(Money <= 10)
								{
									ppp = 7;
								}
								
								System.out.print(" ");
							}
							System.out.println("|");
							System.out.println("===================");
							System.out.println("");
							System.out.println("  Buy factory");
							System.out.println("========================");
							System.out.println("| No | Type            |");
							System.out.println("========================");
							System.out.println("| 1  | Wood factory    |");
							System.out.println("| 2  | Stone factory   |");
							System.out.println("| 3  | Gold factory    |");
							System.out.println("========================");
							System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
							System.out.println("");
							System.out.print("Choose factory [1-3], [0] to go back: ");
							as = scan.nextInt();
							if (as >= 0 && as <= 3)
							{
								zzz = 1;
							}
						}if(as == 1)
						{
							
						} else if (as == 2)
						{
							
						} else if(as == 3)
						{
							
						} else if (as == 0)
						{
							day = 0;
							new Main();
						}
					}
				}else if (b == 3)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					if(pabrikkayu == 0 || pabrikbatu == 0 || pabrikemas == 0)
					{
						System.out.println("You don't own a single factory");
						System.out.println("");
						System.out.println("Press A to continue");
						String ab = scan.next();
						if(ab == "A" || ab == "a")
						{
							
						} else if(ab != "A" || ab != "a")
						{
							
						}
					}
				}else if (b == 4)
				{
					
				}else if (b == 5)
				{
					for(int i = 1; i < 1001; i++) System.out.println("");
					System.out.println("Game Over");
					System.out.println("================");
					System.out.println("Final Score: " + Money);
					System.out.println();
					System.out.println("Press A to continue");
					String ab = scan.next();
					if(ab == "A" || ab == "a")
					{
						new Main();
					}else if(ab != "A" || ab != "a")
					{
						new Main();
					}
				}
			}
		}
		}
	} else if(a== 2)
	{
		System.out.println("Thankyou for playing HHFactory... See you next time!");
	} else if (a != 1 && a != 2)
	{
		new Main();
	}}

	public static void main(String[] args) {
		new Main();

	}

}
