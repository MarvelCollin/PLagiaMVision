package factory;

public class StoneFactory extends Factory{

	String special;
	
	public StoneFactory(String name, int value, String special) {
		super(name, "Wood", value);
		this.special = special;
	}

	public String getSpecial() {
		return special;
	}
	public void setSpecial(String special) {
		this.special = special;
	
	}
}
