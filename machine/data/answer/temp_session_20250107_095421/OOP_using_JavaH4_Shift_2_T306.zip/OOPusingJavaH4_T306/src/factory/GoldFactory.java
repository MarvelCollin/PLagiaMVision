package factory;

public class GoldFactory extends Factory{

	int special;
	
	public GoldFactory(String name, int value, int special) {
		super(name, "Gold", value);
		this.special = special;
	}
	

	public int getSpecial() {
		return special;
	}
	public void setSpecial(int special) {
		this.special = special;

	}
}
