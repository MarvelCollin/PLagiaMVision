package factory;

public class WoodFactory extends Factory{

	String special;
	
	public WoodFactory(String name, int value, String special) {
		super(name, "Wood", value);
		this.special = special;
	}
	

	public String getSpecial() {
		return special;
	}
	public void setSpecial(String special) {
		this.special = special;
	
	}
	

}
