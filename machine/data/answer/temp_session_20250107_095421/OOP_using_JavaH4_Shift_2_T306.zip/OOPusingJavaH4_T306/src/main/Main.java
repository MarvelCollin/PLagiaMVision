package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import factory.Factory;
import factory.GoldFactory;
import factory.StoneFactory;
import factory.WoodFactory;

public class Main {
	
	Scanner sc = new Scanner(System.in);
	ArrayList<Factory> factoryList = new ArrayList<>();
	
	public Main() {
		while(true) {
			int menu = mainMenu();
			switch(menu) {
			case 1:
				User user = new User(0);
				
				playGame(user, factoryList);
				break;
				
			case 2:
				System.out.println("Exiting...");
				return;
			}
			
		}
	}
	
	public void showResource(User user) {
		System.out.println("Day: " + user.getDay());
		System.out.println("================");
		System.out.println("Your Resource");
		System.out.println("================");
		System.out.println("Wood: " + user.getWood());
		System.out.println("Stone: " + user.getStone());
		System.out.println("Gold: " + user.getGold());
		System.out.println("Money: " + user.getMoney());
		System.out.println();
	}
	
	public void playGame(User user, ArrayList<Factory> factoryList) {
		
		while(true) {
			showResource(user);
			
			System.out.println("Actions:");
			System.out.println("1. Finish day");
			System.out.println("2. Buy factory");
			System.out.println("3. View all factory");
			System.out.println("4. Trade center");
			System.out.println("5. Exit game");	
			System.out.print(">> ");
			int menu = sc.nextInt();
			
			switch(menu) {
				case 1:
					// Finish day
					finishDay(user, factoryList);
					break;
				case 2:
					// Buy factory
					buyFactory(user);
					break;
				case 3:
					// View factory
					viewFactory(factoryList);
					break;
				case 4:
					// Trade center
					tradeCenter(user);
					break;
				case 5:
					System.out.println("Exiting...");
					return;
			}
			
			
		}
	}
	
	public void tradeCenter(User user) {
		showResource(user);
		Random random = new Random();
		
		System.out.println("\n\n Trade center");
		System.out.println("=======================");
		
		System.out.println("1. 14 GOLD || 100 MONEY");
		System.out.println("2. 10 WOOD || 100 MONEY");
		System.out.println("3. 12 STONE || 100 MONEY");

		
		while(true) {
			System.out.println("Choose offer [0 to go back]: ");
			int menu = sc.nextInt();
			sc.nextLine();
			
			boolean isEnough = checkResource(user);
			if(!isEnough) {
				System.out.println("Your resources are insufficient..");
				enterTo();
				break;
			}
			
			int userGold = user.getGold();
			int userMoney = user.getMoney();
			int userWood = user.getWood();
			int userStone = user.getStone();
			
			switch (menu) {
			case 1:	
				user.setGold(userGold -= 14);
				user.setMoney(userMoney += 100);
				break;
			case 2:		
				user.setWood(userWood -= 10);
				user.setMoney(userMoney += 100);
				break;
			case 3:				
				user.setStone(userStone -= 12);
				user.setMoney(userMoney += 100);
				break;
			case 0: 
				return;
			default:
				break;
			}
			break;
		}
		
		System.out.println("Transaction completed successfully!");
		enterTo();
		
	}
	
	public void finishDay(User user, ArrayList<Factory> factoryList) {
		int stoneAdd = 0;
		int goldAdd = 0;
		int woodAdd = 0;
		
		for (Factory f : factoryList) {
			if(f.getType() == "Wood") {
				woodAdd += f.getValue();
			} else if(f.getType() == "Stone") {
				stoneAdd += f.getValue();
			} else if(f.getType() == "Gold") {
				goldAdd += f.getValue();
			}
		}
		
		int userStone = user.getStone();
		int userGold = user.getGold();
		int userWood = user.getWood();
		int userDay = user.getDay();
		
		user.setStone(userStone += stoneAdd);
		user.setGold(userGold += goldAdd);
		user.setWood(userWood += woodAdd);
		
		user.setDay(userDay += 1);
	}
	
	public void viewFactory(ArrayList<Factory> factoryList) {
		for (Factory f : factoryList) {
			System.out.println("\n\nName: " + f.getName());
			System.out.println("Type: " + f.getType());
			System.out.println("Production Value: " + f.getValue());
			if(f instanceof WoodFactory) {				
				System.out.println("Special Attribute: " + ((WoodFactory) f).getSpecial());
			}
			if(f instanceof StoneFactory) {				
				System.out.println("Special Attribute: " + ((StoneFactory) f).getSpecial());
			}
			if(f instanceof GoldFactory) {				
				System.out.println("Special Attribute: " + ((GoldFactory) f).getSpecial());
			}
			
			System.out.println("\n\n");
		}
		
		enterTo();
	}
	
	public boolean checkResource(User user) {
		return (user.getGold() >= 10 && user.getStone() >= 10 && user.getWood() >= 10);
	}
	
	public void enterTo() {
		System.out.println("Press ENTER to continue..");
		sc.nextLine();
	}
	
	public void buyFactory(User user) {
		showResource(user);
		
		System.out.println("Buy Factory");
		System.out.println("================");
		System.out.println("1. Wood factory");
		System.out.println("2. Stone factory");
		System.out.println("3. Gold factory");
		System.out.println("To buy any type of factory you need: 10 wood, 10 stone, and 10 gold.");
		
		while(true) {
			
			System.out.print("Choose factory [0 to exit]: ");
			int choice = sc.nextInt();
			sc.nextLine();
			
			boolean isEnough = checkResource(user);
			if(!isEnough) {
				System.out.println("Your resources are insufficient..");
				break;
			}
			
			
			if(choice == 1) {
				// WOOD FACTORY
				
				System.out.println("Input factory detail");
				System.out.println("===========================");
				String name;
				
				while(true) {
					System.out.print("Input factory name: ");
					name = sc.nextLine();
					if(name.length() > 5 && name.length() < 15) break;
				}
				
				String type = "";
				
				while(true) {
					System.out.print("Input wood type name: ");
					type = sc.nextLine();
					if(type.equals("Teak") || 
							type.equals("Mahogany") ||
							type.equals("Oak") ) break;
				}
				
				int gold = user.getGold();
				user.setGold(gold -= 10);
				
				int stone = user.getStone();
				user.setStone(stone -= 10);
				
				int wood = user.getWood();
				user.setWood(wood -= 10);
				
				WoodFactory newFac = new WoodFactory(name, 3, "Wood type: " + type);
				factoryList.add(newFac);
				
				System.out.println("Successfully bought a new factory!\n");
				enterTo();
				break;
			
			} else if(choice == 2) {
				//	STONE FACTORY
				
				System.out.println("Input factory detail");
				System.out.println("===========================");
				String name;
				
				while(true) {
					System.out.print("Input factory name: ");
					name = sc.nextLine();
					if(name.length() > 5 && name.length() < 15) break;
				}
				
				String type = "";
				
				while(true) {
					System.out.print("Input stone type name: ");
					type = sc.nextLine();
					if(type.equals("Granite") || 
							type.equals("Marble") ||
							type.equals("Limestone") ) break;
				}
				
				int gold = user.getGold();
				user.setGold(gold -= 10);
				
				int stone = user.getStone();
				user.setStone(stone -= 10);
				
				int wood = user.getWood();
				user.setWood(wood -= 10);
				
				StoneFactory newFac = new StoneFactory(name, 3, "Stone type: " + type);
				factoryList.add(newFac);
				
				System.out.println("Successfully bought a new factory!\n");
				enterTo();
				break;
				
			} else if(choice == 3) {
				// GOLD FACTORY
				System.out.println("Input factory detail");
				System.out.println("===========================");
				String name;
				
				while(true) {
					System.out.print("Input factory name: ");
					name = sc.nextLine();
					if(name.length() > 5 && name.length() < 15) break;
				}
				
				int purity;
				
				while(true) {
					System.out.print("Input gold purity: ");
					purity = sc.nextInt();
					if(purity >= 18 && purity <= 24) break;
				}
				
				int gold = user.getGold();
				user.setGold(gold -= 10);
				
				int stone = user.getStone();
				user.setStone(stone -= 10);
				
				int wood = user.getWood();
				user.setWood(wood -= 10);
				
				GoldFactory newFac = new GoldFactory(name, 3, purity);
				factoryList.add(newFac);
				
				System.out.println("Successfully bought a new factory!\n");
				enterTo();
				break;
			} else if(choice == 0) {
				break;
			}
		}
	}
	
	
	public int mainMenu() {
		System.out.println("1. Play game");
		System.out.println("2. Exit");
		System.out.print(">> ");
		int menu = sc.nextInt();
		return menu;
	}
	
	
	public static void main(String[] args) {
		new Main();
	}

}
