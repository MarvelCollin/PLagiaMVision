package main;

public class User {
	private int wood;
	private int stone;
	private int gold;
	private int money;
	private int day;
	
	public User(int money) {
		super();
		this.wood = 40;
		this.stone = 40;
		this.gold = 40;
		this.money = money;
		this.day = 1;
	}
	
	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getWood() {
		return wood;
	}
	public void setWood(int wood) {
		this.wood = wood;
	}
	public int getStone() {
		return stone;
	}
	public void setStone(int stone) {
		this.stone = stone;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
}
