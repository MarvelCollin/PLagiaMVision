package model;

public class StoneF extends Factory{
	private int prodVal;
	private String specialAtribute;
	public StoneF(String name, String uid, String type, int prodVal, String specialAtribute) {
		super(name, uid, type);
		this.prodVal = prodVal;
		this.specialAtribute = specialAtribute;
	}
	public int getProdVal() {
		return prodVal;
	}
	public void setProdVal(int prodVal) {
		this.prodVal = prodVal;
	}
	public String getSpecialAtribute() {
		return specialAtribute;
	}
	public void setSpecialAtribute(String specialAtribute) {
		this.specialAtribute = specialAtribute;
	}
	
	
}
