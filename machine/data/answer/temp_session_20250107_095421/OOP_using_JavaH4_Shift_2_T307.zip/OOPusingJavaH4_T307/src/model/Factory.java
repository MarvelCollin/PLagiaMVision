package model;

public class Factory {

	protected String name;
	protected String uid;
	protected String type;
	
	public Factory(String name, String uid, String type) {
		super();
		this.name = name;
		this.uid = uid;
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
