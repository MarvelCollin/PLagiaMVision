package model;

public class Player {

	private String name;
	private String id;
	private int resourceOfWood;
	private int resourceOfStone;
	private int resourceOfGold;
	private int resourceOfMoney;
	
	public Player(String name, String id, int resourceOfWood, int resourceOfStone, int resourceOfGold,
			int resourceOfMoney) {
		super();
		this.name = name;
		this.id = id;
		this.resourceOfWood = resourceOfWood;
		this.resourceOfStone = resourceOfStone;
		this.resourceOfGold = resourceOfGold;
		this.resourceOfMoney = resourceOfMoney;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getResourceOfWood() {
		return resourceOfWood;
	}
	public void setResourceOfWood(int resourceOfWood) {
		this.resourceOfWood = resourceOfWood;
	}
	public int getResourceOfStone() {
		return resourceOfStone;
	}
	public void setResourceOfStone(int resourceOfStone) {
		this.resourceOfStone = resourceOfStone;
	}
	public int getResourceOfGold() {
		return resourceOfGold;
	}
	public void setResourceOfGold(int resourceOfGold) {
		this.resourceOfGold = resourceOfGold;
	}
	public int getResourceOfMoney() {
		return resourceOfMoney;
	}
	public void setResourceOfMoney(int resourceOfMoney) {
		this.resourceOfMoney = resourceOfMoney;
	}
	
	
	
}
