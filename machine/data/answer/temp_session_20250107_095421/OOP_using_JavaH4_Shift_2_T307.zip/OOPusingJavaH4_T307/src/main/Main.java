package main;

import java.util.ArrayList;
import java.util.Scanner;

import model.Factory;
import model.GoldF;
import model.Player;
import model.StoneF;
import model.WoodF;

public class Main {
	Scanner scanner = new Scanner(System.in);
	ArrayList<Player> players = new ArrayList<>();
	ArrayList<Factory> factories = new ArrayList<>();
	
	Player pUser = new Player("", "B2800AL", 40, 40, 40, 0);
	int day = 1;
	
	void viewAllFactory() {
		if (factories.isEmpty()) {
			System.out.println("You don't have any");
		}else {
			for (Factory factory : factories) {
				if (factory instanceof WoodF) {
					System.out.printf("Name: %s - Type: %s - Production Value: %d - Special Atribure: %s\n", factory.getName(), factory.getType(), ((WoodF) factory).getProdVal(), ((WoodF) factory).getSpecialAtribute());
				}else if(factory instanceof StoneF) {
					System.out.printf("Name: %s - Type: %s - Production Value: %d - Special Atribure: %s\n", factory.getName(), factory.getType(), ((StoneF) factory).getProdVal(), ((StoneF) factory).getSpecialAtribute());
				}else if(factory instanceof GoldF) {
					System.out.printf("Name: %s - Type: %s - Production Value: %d - Special Atribure: %s\n", factory.getName(), factory.getType(), ((GoldF) factory).getProdVal(), ((GoldF) factory).getSpecialAtribute());
				}
			}
		}
		System.out.print("Press ENTER to continue...");
		scanner.nextLine();
	}
	
	void buyFactory() {
		System.out.println("=================");
		System.out.println("| Your Resource |");
		System.out.println("=================");
		System.out.printf("|Wood: %d|\n", pUser.getResourceOfWood());
		System.out.printf("|Stone: %d|\n", pUser.getResourceOfStone());
		System.out.printf("|Gold: %d|\n", pUser.getResourceOfGold());
		System.out.printf("|Money: %d|\n", pUser.getResourceOfMoney());
		System.out.println("=================\n");
		
		System.out.println("Buy Factory");
		System.out.println("====================");
		System.out.println("| No | Type        |");
		System.out.println("====================");
		System.out.println("|1.  |Wood Factory |");
		System.out.println("|2.  |Stone Factory|");
		System.out.println("|3   |Gold Factory |");
		System.out.println("====================");
		System.out.println("Buy cost 10 wood, 10 stone, 10 gold");
		System.out.print("Choose factory [1-3], [0] to go back: ");
		if (pUser.getResourceOfWood() < 10 || pUser.getResourceOfStone() < 10 || pUser.getResourceOfGold() < 10) {
			System.out.println("Not enough resource");
		}else {
			int choose;
			choose = scanner.nextInt();
			scanner.nextLine();
			pUser.setResourceOfWood(pUser.getResourceOfWood()-10);
			pUser.setResourceOfStone(pUser.getResourceOfStone()-10);
			pUser.setResourceOfGold(pUser.getResourceOfGold()-10);
			if (choose == 1) {
				createWoodF();
			}else if(choose == 2) {
				createStoneF();
			}else if(choose == 3) {
				createGoldF();
			}
		}
	}
	
	void createWoodF() {
		System.out.println("Input Factory Detail");
		System.out.println("====================");
		System.out.print("Input factory name: ");
		String name = scanner.nextLine();
		System.out.print("Input type: ");
		String type = scanner.nextLine();
		
		factories.add(new WoodF(name, pUser.getId(), "Wood", 3, type));
		System.out.println("Succes create factory");
		gamePlay();
	}
	
	void createStoneF() {
		System.out.println("Input Factory Detail");
		System.out.println("====================");
		System.out.print("Input factory name: ");
		String name = scanner.nextLine();
		System.out.print("Input type: ");
		String type = scanner.nextLine();
		
		factories.add(new StoneF(name, pUser.getId(), "Stone", 3, type));
		System.out.println("Succes create factory");
		gamePlay();
	}
	
	void createGoldF() {
		System.out.println("Input Factory Detail");
		System.out.println("====================");
		System.out.print("Input factory name: ");
		String name = scanner.nextLine();
		System.out.print("Input type: ");
		String type = scanner.nextLine();
		
		factories.add(new WoodF(name, pUser.getId(), "Gold", 3, type));
		System.out.println("Succes create factory");
		gamePlay();
	}
	
	void gamePlay() {
		while (true) {
			System.out.println("Day: "+ day);
			System.out.println("=================");
			System.out.println("| Your Resource |");
			System.out.println("=================");
			System.out.printf("|Wood: %d|\n", pUser.getResourceOfWood());
			System.out.printf("|Stone: %d|\n", pUser.getResourceOfStone());
			System.out.printf("|Gold: %d|\n", pUser.getResourceOfGold());
			System.out.printf("|Money: %d|\n", pUser.getResourceOfMoney());
			System.out.println("=================\n");
			System.out.println("Actions:\n1. Finisih day\n2. Buy factory\n3. View all factory\n4. Trade Center\5. Exit\n");
			System.out.print("Choose action [1-5]: ");
			int action;
			action = scanner.nextInt();
			scanner.nextLine();
			if (action == 1) {
				
			}else if(action == 2) {
				buyFactory();
			}else if(action == 3) {
				viewAllFactory();
			}else if(action == 4) {
				
			}else if(action == 5) {
				menu();
			}else {
				System.out.println("Invalid input");
			}
		}
	}
	
	void menu() {
		while(true) {
			int selection;
			System.out.println("1. Play Game");
			System.out.println("2. Exit");
			System.out.print(">> ");
			selection = scanner.nextInt();
			scanner.nextLine();
			
			if (selection == 1) {
				gamePlay();
			} else if (selection == 2) {
				return;
			}
		}
	}

	public Main() {
		menu();
	}

	public static void main(String[] args) {
		new Main();
	}

}
