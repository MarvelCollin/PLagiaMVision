package factory;


import java.util.Scanner;

import resource.Resource;

public class GoldFactory extends Resource {
	Scanner scan = new Scanner(System.in);
	private Integer purity;
	private Integer production;
	public GoldFactory(Integer wood, Integer stone, Integer gold, Integer money, Integer purity, Integer production) {
		super(wood, stone, gold, money);
		this.purity = purity;
		this.production = production;
	}
	public Integer getPurity() {
		return purity;
	}
	public void setType(Integer purity) {
		this.purity = purity;
	}
	public Integer getProduction() {
		return production;
	}
	public void setProduction(Integer production) {
		this.production = production;
	}
	
	public void inputgold() {
		System.out.println("Input gold purity [Teak | Mahogany | Oak] (Case sensitive): ");
		Integer purity = scan.nextInt();
		System.out.println("Successfully bought a new factory!");
	}
	

}
