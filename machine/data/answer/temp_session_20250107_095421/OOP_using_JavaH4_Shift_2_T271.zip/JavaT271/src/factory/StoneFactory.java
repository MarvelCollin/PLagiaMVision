package factory;

import java.util.Scanner;

import resource.Resource;

public class StoneFactory extends Resource {
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getProduction() {
		return production;
	}
	public void setProduction(Integer production) {
		this.production = production;
	}
	public StoneFactory(Integer wood, Integer stone, Integer gold, Integer money, String type, Integer production) {
		super(wood, stone, gold, money);
		this.type = type;
		this.production = production;
	}
	Scanner scan = new Scanner(System.in);
	private String type;
	private Integer production;
	
	public void inputstone() {
		System.out.println("Input stone type [Granite | Marble | Limestone] (Case sensitive): ");
		String type = scan.nextLine();
		System.out.println("Successfully bought a new factory!");
	}

}
