package factory;

import java.util.Scanner;

import resource.Resource;

public class WoodFactory extends Resource {
	Scanner scan = new Scanner(System.in);
	private String type;
	private Integer production;
	public WoodFactory(Integer wood, Integer stone, Integer gold, Integer money, String type, Integer production) {
		super(wood, stone, gold, money);
		this.type = type;
		this.production = production;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getProduction() {
		return production;
	}
	public void setProduction(Integer production) {
		this.production = production;
	}
	public void inputwood() {
		System.out.println("Input wood type [Teak | Mahogany | Oak] (Case sensitive): ");
		String type = scan.nextLine();
		System.out.println("Successfully bought a new factory!");
	}

}
