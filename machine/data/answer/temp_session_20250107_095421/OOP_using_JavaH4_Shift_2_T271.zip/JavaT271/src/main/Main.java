package main;

import java.util.Random;
import java.util.Scanner;

import resource.Resource;

public class Main {
	Scanner scan = new Scanner(System.in);
		int day = 1;
		int wood = 40;
		int gold = 40;
		int stone = 40;
		int money = 0;
	Resource resource = new Resource(wood, stone, gold, money);

	public Main(){
		menu();
	}
	
	public void menu() {
		while(true) {
		System.out.println("1. Play game");
		System.out.println("2. Exit");
		System.out.print(">> ");
		int opsi = scan.nextInt();
		switch (opsi) {
		case 1:
			play();
			break;
		case 2:
			exit();
			break;

		default:
			menu();
			break;
		}
		}
	}
	
	public void play() {

//		Resource resource = new Resource(wood, stone, gold, money);
		System.out.println("Day: "+ day);
		resource.dislayresource();

		System.out.println();
		System.out.println("Actions:");
		System.out.println("1. Finish day");
		System.out.println("2. Buy factory");
		System.out.println("3. View all factory");
		System.out.println("4. Trade Center");
		System.out.println("5. Exit game");
		System.out.println();
		System.out.print("Choose action [1-5]: ");
		int action = scan.nextInt();
		switch (action) {
		case 1:
			System.out.println("Going to next day");
			System.out.println();
			System.out.println("Press enter to continue...");
			String enter = scan.nextLine();
			day++;
			play();
			break;
		case 2:
			buy();
			break;
		case 3:
			displayfactory();
			break;
		case 4:
			tradeCenter();
			break;
		case 5:
			System.out.println("GAMEOVER");
			System.out.println("===============");
			System.out.println("Final score: "+money);
			System.out.println();
			System.exit(0);
			break;

		default:
			break;
		}
	}
	
	public void exit() {
		System.out.println("Bye Bye");
		System.exit(0);
	}
	
	public void buy() {
		System.out.println("  Buy factory");
		System.out.println("========================");
		System.out.println("| No | Type            |");
		System.out.println("========================");
		System.out.println("| 1  | Wood factory    |");
		System.out.println("| 2  | Stone factory   |");
		System.out.println("| 3  | Gold factory    |");
		System.out.println("========================");
		System.out.println("To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.");
		System.out.println();
		System.out.print("Choose factory [1-3], [0] to go back: ");
		int fact = scan.nextInt();
		switch (fact) {
		case 1:
			factorydetail();
			break;
		case 2:
			
			break;
		case 3:
			
			break;
		case 0:
			play();
			break;

		default:
			break;
		}
	}
	
	public void factorydetail() {
		System.out.println("Input factory detail");
		System.out.println("=========================");
		System.out.print("Input factory name [5 - 15 characters] (inclusive): ");
		String factoryname = scan.nextLine();
		if(factoryname.length()<5 || factoryname.length()>15) {
			factorydetail();
		}
	}
	
	public void tradeCenter() {
		Random rand = new Random();
		int randomnum = rand.nextInt(10);
		int randomnum1 = rand.nextInt(10);
		int randomnum2 = rand.nextInt(10);
		
//		String acak = rand.toString();
		
		resource.dislayresource();
		System.out.println();
		System.out.println("  Trade Center");
		System.out.println("================================");
		System.out.println("| No | Cost       | Reward     |");
		System.out.println("================================");
		System.out.printf("| 1  | %d %s    | 100 MONEY  |\n", randomnum);
		System.out.printf("| 2  | %d %s    | 100 MONEY  |\n",randomnum1);
		System.out.printf("| 3  | %d %s    | 100 MONEY  |\n",randomnum2);
		System.out.println("================================");
		System.out.println();
		System.out.print("Choose offer [1-3] [0] to go back: ");
		int offer = scan.nextInt();
		switch (offer) {
		case 1:
			System.out.println("Transaction completed successfully!");
			System.out.println();
			System.out.println("Press enter to continue...");
			break;
		case 2:
			System.out.println();
			break;
		case 3:
			System.out.println();
			break;
		case 0:
			play();
			break;

		default:
			break;
		}
	}
	
	public void displayfactory() {
		System.out.println("============================================================================");
		System.out.println("| Name             | Type       | Production Value | Special Attribute     |");
		System.out.println();
		
	}

	public static void main(String[] args) {
		new Main();

	}

}
