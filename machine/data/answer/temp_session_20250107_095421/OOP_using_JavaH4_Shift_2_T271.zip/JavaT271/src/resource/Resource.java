package resource;

public class Resource {
	
	private Integer wood;
	private Integer stone;
	private Integer gold;
	private Integer money;
	public Resource(Integer wood, Integer stone, Integer gold, Integer money) {
		super();
		this.wood = wood;
		this.stone = stone;
		this.gold = gold;
		this.money = money;
	}
	public Integer getWood() {
		return wood;
	}
	public void setWood(Integer wood) {
		this.wood = wood;
	}
	public Integer getStone() {
		return stone;
	}
	public void setStone(Integer stone) {
		this.stone = stone;
	}
	public Integer getGold() {
		return gold;
	}
	public void setGold(Integer gold) {
		this.gold = gold;
	}
	public Integer getMoney() {
		return money;
	}
	public void setMoney(Integer money) {
		this.money = money;
	}
	
	public void dislayresource() {
		System.out.println("===================");
		System.out.println("| Your resources  |");
		System.out.println("===================");
		System.out.println("| Wood: " + wood );
		System.out.println("| Stone: "+ stone);
		System.out.println("| Gold: "+ gold);
		System.out.println("| Money: "+ money);
		System.out.println("===================");
	}

}
