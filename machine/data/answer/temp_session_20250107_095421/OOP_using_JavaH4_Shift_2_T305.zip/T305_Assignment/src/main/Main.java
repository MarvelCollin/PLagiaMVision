package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import model.Factory;
import model.GoldFactory;
import model.StoneFactory;
import model.User;
import model.WoodFactory;

public class Main {
	Scanner sc = new Scanner(System.in);
	User currentUser = new User(40, 40, 40, 0);
	ArrayList<Factory> factoryList = new ArrayList<>();
	Random random = new Random();
	
	void finishGame() {
		currentUser.setDay(currentUser.getDay() + 1);
		currentUser.setWood(40);
		currentUser.setStone(40);
		currentUser.setStone(40);
		currentUser.setMoney(0);
	}
	
	void showResource() {
		System.out.printf("| %-13s |\n",
	            "Your resources");
		System.out.println("-".repeat(17));

		System.out.printf("%-5s: %-5d\n", "Wood", currentUser.getWood());

		System.out.printf("%-5s: %-5d\n", "Stone", currentUser.getStone());
	    
		System.out.printf("%-5s: %-5d\n", "Gold", currentUser.getGold());
	    
		System.out.printf("%-5s: %-5d\n", "Money", currentUser.getMoney());

		System.out.println("-".repeat(17));
	}
	
	void tradeCenter() {
		showResource();
		
		System.out.println();
		System.out.println("Trade Center");
		
		System.out.println("1. Cost : 14 GOLD | Reward : 100 MONEY");
		
		System.out.println("2. Cost : 13 GOLD | Reward : 100 MONEY");
		
		System.out.println("3. Cost : 12 WOOD | Reward : 100 MONEY");
		
		Integer input;
		
		while(true) {
			System.out.println("Choose Offer: ");
			input = sc.nextInt(); sc.nextLine();
			
			if(input == 0) {
				return;
			}
			
			if(input == 1) {
				if(currentUser.getGold() >= 14) {
					currentUser.setMoney(currentUser.getMoney() + 100);
					currentUser.setGold(currentUser.getGold() - 14);
					
					System.out.println("Transaction Completed!");
					
					Util.enterToContinue();
					return;
				} else {
					break;
				}
			}
			
			if(input == 2) {
				if(currentUser.getGold() >= 13) {
					currentUser.setMoney(currentUser.getMoney() + 100);
					
					currentUser.setGold(currentUser.getGold() - 13);
					
					System.out.println("Transaction Completed!");
					
					Util.enterToContinue();
					return;
				} else {
					break;
				}
			}
			
			if(input == 3) {
				if(currentUser.getWood() >= 12) {
					currentUser.setMoney(currentUser.getMoney() + 100);
					currentUser.setGold(currentUser.getWood() - 12);
					
					System.out.println("Transaction Completed!");
					
					Util.enterToContinue();
					return;
				} else {
					break;
				}
			}
			
		}
		
		System.out.println("You dont have enough resource!");
		
		Util.enterToContinue();
	}
	
	void viewAllFactory() {
		if(factoryList.isEmpty()) {
			System.out.println("Data is empty!");
			Util.enterToContinue();
			return;
		}
		
		System.out.println("=".repeat(40));
		System.out.printf("%-10s | %-5s | %-20s | %-10s\n",
	            "Name",
	            "Type",
	            "Production Value",
	            "Special Attribute");
		System.out.println("=".repeat(40));
		for (Factory factory : factoryList) {
			System.out.printf("%-10s | %-5s | %-20d |",
					factory.getName(),
					factory.getType(),
					factory.getProductionVal(),
					"Special Attribute");		
			
			if(factory instanceof WoodFactory) {
				System.out.printf("%-10s %-10s", "Wood type:", ((WoodFactory) factory).getWoodType());
			}
			
			if(factory instanceof StoneFactory) {
				System.out.printf("%-10s %-10s", "Stone type:", ((StoneFactory) factory).getStoneType());
			}
			
			if(factory instanceof GoldFactory) {
				System.out.printf("%-10s %-10d", "Gold Purity:", ((GoldFactory) factory).getGoldPurity());
			}
			
			System.out.println("\n");
		}
		
		Util.enterToContinue();
		
}
	
	void buyFactory() {

		showResource();
		System.out.println();
		
		Integer factoryId = random.nextInt(100);
		
		System.out.println("Buy Factory");
		System.out.println("1. Wood Factory");
		System.out.println("2. Stone Factory");
		System.out.println("3. Gold Factory");
		System.out.println(">>");
		
		System.out.println("To buy any factory, u need 10 wood, 10 stone, and 10 gold");
		
		System.out.println("Choose Factory [1-3]");
		
		Integer factoryType;
		factoryType= sc.nextInt(); sc.nextLine();
		if(factoryType == 0) return; 
		
		String name;
		while(true) {
			System.out.println("Input fac name: ");
			name = sc.nextLine();
			
			if(name.length() >= 3 && name.length() <= 15) {
				break;
			} else {
				System.out.println("Factory name must be 5-15");
			}
			
			if(factoryType == 1) {
				if(currentUser.getWood() >= 10) {
					break;
				} else {
					System.out.println("you dont have enough resource");
				}
			} 
			
			else if(factoryType == 2) {
				if(currentUser.getStone() >= 10) {
					break;
				} else {
					System.out.println("you dont have enough resource");
				}
			}
			
			else if(factoryType == 3) {
				if(currentUser.getGold() >= 10) {
					break;
				} else {
					System.out.println("you dont have enough resource");
				}
			}
		}
		
		switch (factoryType) {
		case 1:			
			String wood;
			while(true) {
				System.out.println("Input wood Type: ");
				wood = sc.nextLine();
				
				if(wood.equalsIgnoreCase("Teak")
						|| wood.equalsIgnoreCase("Mahogany")
						|| wood.equalsIgnoreCase("Oak")) {
					break;
				}
			}
			currentUser.setWood(currentUser.getWood()- 10);
			
			factoryList.add(new WoodFactory(name, "Wood", 3, wood));
			
			break;
		case 2: 
			String stone;
			
			while(true) {
				System.out.println("Input Stone Type: ");
				stone = sc.nextLine();
				
				if(stone.equalsIgnoreCase("Granite")
						|| stone.equalsIgnoreCase("Marble")
						|| stone.equalsIgnoreCase("Limestone")) {
					break;
				}
			}
			currentUser.setStone(currentUser.getStone()- 10);
			
			factoryList.add(new StoneFactory(name, "Stone", 3, stone));
			
		break;
		case 3:
			int gold;
			
			while(true) {
				System.out.println("Input Gold Purity: ");
				gold = sc.nextInt(); sc.nextLine();
				
				
				if(gold > 17 && gold < 25) {
					break;
				} else {
					System.out.println("Gold must be 18 - 24");
				}
				
				currentUser.setGold(currentUser.getGold() - 10);
				
				factoryList.add(new GoldFactory(name, "Gold", 3, 24));
				
			}
			
			break;
		default:
			break;
		}
		
		System.out.println("Successfully bought a factory");
		
		Util.enterToContinue();
	}
	
	void playGame() {
		int input;
		
		showResource();
		
		do {
			System.out.println("Day" + currentUser.getDay());
			System.out.println("Actions:");
			System.out.println("1. Finish day");
			System.out.println("2. Buy Factory");
			System.out.println("3. View all factory");
			System.out.println("4. Trade Center");
			System.out.println("5. Exit Game");
		
			System.out.print(">> ");
			
			try {
				input = sc.nextInt();
			} catch (Exception e) {
				input = 1;
				// TODO: handle exception
			}
			sc.nextLine();
			
			switch (input) {
			case 1:
				finishGame();
				break;
			case 2:
				buyFactory();
				break;
			case 3:
				viewAllFactory();
				break;
			case 4:
				tradeCenter();
			default:
				playGame(); 
				break;
			}
		} while(input != 5);
	}
	
	public Main() {
		int input;
		
		do {
			System.out.println("--HH Factory--");
			System.out.println("1. Play Game");
			System.out.println("2. Exit ");
			System.out.print(">> ");
			
			try {
				input = sc.nextInt();
			} catch (Exception e) {
				input = 1;
				// TODO: handle exception
			}
			sc.nextLine();
			
			
			switch (input) {
			case 1:
				playGame();
				break;
			case 2:
				break;
			default:
				playGame(); 
				break;
			}
		} while(input != 2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
