package main;

import java.util.Scanner;

public class Util {
	public static Scanner sc = new Scanner(System.in);
	
	public static void enterToContinue() {
		System.out.println("Press ENTER to continue");
		sc.nextLine();
	}
	
//	public static void cls() {
//		System.out.println("\n".repeat("20"));
//	}
	
}
