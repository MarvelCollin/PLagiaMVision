package model;

public class WoodType {
	private String woodType;
	
	public String getWoodType() {
		return woodType;
	}

	public void setWoodType(String woodType) {
		this.woodType = woodType;
	}

	public WoodType(String woodType) {
		super();
		this.woodType = woodType;
	}


}
