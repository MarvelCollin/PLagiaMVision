package model;

public class WoodFactory extends Factory {
	private String woodType;

	public String getWoodType() {
		return woodType;
	}

	public void setWoodType(String woodType) {
		this.woodType = woodType;
	}

	public WoodFactory(String name, String type, int productionVal, String woodType) {
		super(name, type, productionVal);
		this.woodType = woodType;
	}
}
