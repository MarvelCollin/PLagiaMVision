package model;

public class StoneFactory extends Factory {
	private String StoneType;
	
	public String getStoneType() {
		return StoneType;
	}

	public void setStoneType(String stoneType) {
		StoneType = stoneType;
	}

	public StoneFactory(String name, String type, int productionVal, String stoneType) {
		super(name, type, productionVal);
		StoneType = stoneType;
	}
}
