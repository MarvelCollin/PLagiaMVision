package model;

public class Factory {
	protected String name;
	protected String type;
	protected int productionVal;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getProductionVal() {
		return productionVal;
	}

	public void setProductionVal(int productionVal) {
		this.productionVal = productionVal;
	}


	public Factory(String name, String type, int productionVal) {
		super();
		this.name = name;
		this.type = type;
	}
	
	

}
