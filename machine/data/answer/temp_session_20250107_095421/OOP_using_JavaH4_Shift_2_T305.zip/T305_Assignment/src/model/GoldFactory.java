package model;

public class GoldFactory extends Factory{
	private Integer goldPurity;
	
	public Integer getGoldPurity() {
		return goldPurity;
	}

	public void setGoldPurity(Integer goldPurity) {
		this.goldPurity = goldPurity;
	}

	public GoldFactory(String name, String type, int productionVal, Integer goldPurity) {
		super(name, type, productionVal);
		this.goldPurity = goldPurity;
	}

	
}
