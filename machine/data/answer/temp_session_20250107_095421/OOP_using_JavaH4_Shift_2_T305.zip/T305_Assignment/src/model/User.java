package model;

import java.util.ArrayList;

public class User {
	private Integer day;
	private Integer wood;
	private Integer stone;
	private Integer gold;
	private Integer money;
	private ArrayList<Integer> factoryIds;
	

	public Integer getDay() {
		return day;
	}


	public void setDay(Integer day) {
		this.day = day;
	}


	public Integer getWood() {
		return wood;
	}


	public void setWood(Integer wood) {
		this.wood = wood;
	}


	public Integer getStone() {
		return stone;
	}


	public void setStone(Integer stone) {
		this.stone = stone;
	}


	public Integer getGold() {
		return gold;
	}


	public void setGold(Integer gold) {
		this.gold = gold;
	}


	public Integer getMoney() {
		return money;
	}


	public void setMoney(Integer money) {
		this.money = money;
	}


	public ArrayList<Integer> getFactoryIds() {
		return factoryIds;
	}


	public void setFactoryIds(ArrayList<Integer> factoryIds) {
		this.factoryIds = factoryIds;
	}


	public User(int wood, int stone, int gold, int money) {
		super();
		this.day = 1;
		this.wood = 40;
		this.stone = 40;
		this.gold = 40;
		this.money = 0;
		this.factoryIds = new ArrayList<>();
	}



		
	
}
