package model;

public class Gold extends Factory {
	private int purity;

	public Gold(int type, String name, int purity) {
		super(type, name);
		this.purity = purity;
	}

	public int getPurity() {
		return purity;
	}

	public void setPurity(int purity) {
		this.purity = purity;
	}
	
}
