package model;

public class Stone extends Factory {
	private String sType;

	public Stone(int type, String name, String sType) {
		super(type, name);
		this.sType = sType;
	}

	public String getsType() {
		return sType;
	}

	public void setsType(String sType) {
		this.sType = sType;
	}
	
}
