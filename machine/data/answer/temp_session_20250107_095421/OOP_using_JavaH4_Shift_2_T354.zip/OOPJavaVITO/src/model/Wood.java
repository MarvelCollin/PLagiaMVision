package model;

public class Wood extends Factory {
	private String wType;

	public Wood(int type, String name, String wType) {
		super(type, name);
		this.wType = wType;
	}

	public String getwType() {
		return wType;
	}

	public void setwType(String wType) {
		this.wType = wType;
	}
	
}
