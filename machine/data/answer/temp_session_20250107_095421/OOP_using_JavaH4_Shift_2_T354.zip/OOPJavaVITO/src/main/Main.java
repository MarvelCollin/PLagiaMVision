package main;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import model.Factory;
import model.Gold;
import model.Stone;
import model.Wood;

public class Main {
	Scanner scan = new Scanner(System.in);
	Vector<Factory> factoryList = new Vector<>();
	Random rand = new Random();
	int wood=40;
	int stone=40;
	int gold=40;
	int money=0;
	int day=1;
	int[] tradeType;
	int[] cost;
	
	private void finish() {
		for(Factory i: factoryList) {
			if(i.getType()==1) wood+=3;
			else if(i.getType()==2) stone+=3;
			else if(i.getType()==3) gold+=3;
		}
		day++;
		for (int i = 0; i < 3; i++) {
			cost[i] = 10+ rand.nextInt(10);
			tradeType[i] = 1 + rand.nextInt();
		}
		
	}
	
	private void buy() {
		System.out.print("  Buy factory\r\n" + 
				"========================\r\n" + 
				"| No | Type            |\r\n" + 
				"========================\r\n" + 
				"| 1  | Wood factory    |\r\n" + 
				"| 2  | Stone factory   |\r\n" + 
				"| 3  | Gold factory    |\r\n" + 
				"========================\r\n" + 
				"To buy any type of factory you need: 10 Wood, 10 Stone and 10 Gold.\r\n" + 
				"\r\n"
				);
		int type=0;
		String name;
		while(true) {
			System.out.print("Choose factory [1-3], [0] to go back: ");
			type = scan.nextInt();
			scan.nextLine();
			if(type<=3 && type >=0) break;
		}
		if(type==0) {
			return;
		} 
		
		
		if( wood<10 || stone<10 || gold<10) {
			System.out.println("You don't have enough resources!");
			System.out.println("Press Enter to continue...");
			scan.nextLine();
			return;
		}
		
		System.out.print("Input factory detail\r\n" + 
				"=========================\r\n");
		while(true) {
			System.out.println("Input factory name [5 - 15 characters] (inclusive): ");
			name = scan.nextLine();
			if(name.length()<=15 && name.length() >=5) break;
		}
		Factory f = new Factory(type, name);
		if(type==1) {
			String wType;
			
			while(true) {
				System.out.print("Input wood type [Teak | Mahogany | Oak] (case sensitive): ");
				wType = scan.nextLine();
				if(wType.equals("Teak")||wType.equals("Mahogany")||wType.equals("Oak")) break;
			}
			factoryList.add(new Wood(type, name, wType));
			
		} else if(type==2) {
			String sType;
			
			while(true) {
				System.out.print("Input stone type [Granite | Marble | Limestone] (case sensitive): ");
				sType = scan.nextLine();
				if(sType.equals("Granite")||sType.equals("Marble")||sType.equals("Limestone")) break;
			}
			factoryList.add(new Stone(type, name, sType));
			
		} else if(type==3) {
			int purity;
			
			while(true) {
				System.out.print("Input gold purity [18 - 24] (inclusive): ");
				purity = scan.nextInt();
				if(purity>=18 && purity<=24) break;
			}
			factoryList.add(new Gold(type, name, purity));
		}
		wood-=10;
		stone-=10;
		gold-=10;
	}
	
	private void view() {
		
		
		if(factoryList.isEmpty()) {
			System.out.println("You Dont Own A Factory");
			System.out.println("Press enter to continue");
			scan.nextLine();
			return;
		}
		
		System.out.println("============================================================================\r\n" + 
				"| Name             | Type       | Production Value | Special Attribute     |\r\n" + 
				"============================================================================");
			for(Factory i : factoryList) {
				String tipe = null;
				if(i.getType() == 1) {
					tipe = "Wood";
				} else if(i.getType() == 2) {
					tipe = "Stone";
				} else if(i.getType() == 3) {
					tipe = "Gold";
				} 
				String special = null;
				if(i.getType() == 1) {
					special = "Wood Type: " + ((Wood)i).getwType();
				} else if(i.getType() == 2) {
					special = "Stone Type: " + ((Stone)i).getsType();
				} else if(i.getType() == 3) {
					special = "Gold Purity: " + ((Gold)i).getPurity();
				} 
				
				System.out.printf("| %-17s| %-11s| %-16s | %-22s|\n", i.getName(), tipe,"3",special);
				
			}
			System.out.println("============================================================================");
			System.out.println("Press enter to continue");
			scan.nextLine();
	}
	
	private void trade() {
		int i;
		System.out.print("===================\r\n" + 
				"| Your resources  |\r\n" + 
				"===================\r\n" + 
				"| Wood: "+wood+"        |\r\n" + 
				"| Stone: "+stone+"       |\r\n" + 
				"| Gold: "+gold+"        |\r\n" + 
				"| Money: "+money+"        |\r\n" + 
				"===================\r\n");
		
		System.out.println("================================\r\n" + 
				"| No | Cost       | Reward     |\r\n" + 
				"================================");
		
		String harga = "";
		for (int j = 0; j < 3; j++) {
			if(tradeType[j]==1) harga = cost[j] + " WOOD";
			else if(tradeType[j]==2) harga = cost[j] + " Stone";
			else if(tradeType[j]==3) harga = cost[j] + " GOLD";
			
			System.out.printf("| %-3d| %-11s| 100 MONEY |\n", j+1, harga);
		}
		
		int offer = scan.nextInt();
		switch(offer) {
		case 1: break;
		case 2: break;
		case 3: break;
		case 0: return;
		}
	}
	
	private void exitGame() {
		
	}
	
	
	private void play() {
		
	
		int option=0;
		do {
			System.out.println();
			System.out.print("  Day: "+day+"\r\n" + 
					"===================\r\n" + 
					"| Your resources  |\r\n" + 
					"===================\r\n" + 
					"| Wood: "+wood+"        |\r\n" + 
					"| Stone: "+stone+"       |\r\n" + 
					"| Gold: "+gold+"        |\r\n" + 
					"| Money: "+money+"        |\r\n" + 
					"===================\r\n" + 
					"\r\n" + 
					"Actions:\r\n" + 
					"1. Finish day\r\n" + 
					"2. Buy factory\r\n" + 
					"3. View all factory\r\n" + 
					"4. Trade center\r\n" + 
					"5. Exit game\r\n" + 
					"\r\n");
			System.out.print("Choose action [1-5]: ");
			option = scan.nextInt();
			scan.nextLine();
			
			switch(option) {
			case 1: finish();break;
			case 2: buy();break;
			case 3: view();break;
			case 4: trade();break;
			case 5: exitGame();break;
			}
		} while(option !=5);
	}
	
	
	public Main() {
		// TODO Auto-generated constructor stub
		int option = 0;
		do {
			System.out.print("  /\\  /\\/\\  /\\/ __\\_ _  ___| |_ ___  _ __ _   _\r\n" + 
					" / /_/ / /_/ / _\\/ _` |/ __| __/ _ \\| '__| | | |\r\n" + 
					"/ __  / __  / / | (_| | (__| || (_) | |  | |_| |\r\n" + 
					"\\/ /_/\\/ /_/\\/   \\__,_|\\___|\\__\\___/|_|   \\__, |\r\n" + 
					"                                          |___/\r\n" + 
					"\r\n" + 
					"1. Play game\r\n" + 
					"2. Exit\r");
			System.out.print(">> ");
			option = scan.nextInt();
			scan.nextLine();
			
			switch(option) {
			case 1: play();break;
			case 2: break;
			}
			
		} while (option!=2);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
