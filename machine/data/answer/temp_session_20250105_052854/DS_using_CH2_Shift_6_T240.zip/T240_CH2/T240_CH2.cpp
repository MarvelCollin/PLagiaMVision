#include <stdio.h>
#include <stdlib.h>
#include <time.h>

	char map[3][3] = {
		{'1', '2', '3'},
		{'4', '5', '6'},
		{'7', '8', '9'}
	};

	void drawMap() {
	
	char map[3][3];
	printf ("                \n");
	printf ("      |    |    \n");
	printf ("    %c  |  %c  |  %c  \n", map[0][0], map[0][1], map[0][2]);	
	printf ("  ____|____|____\n");
	printf ("      |    |    \n");
	printf ("    %c  |  %c  |  %c  \n", map[0][0], map[0][1], map[0][2]);
	printf ("  ____|____|____\n");
	printf ("      |    |    \n");
	printf ("    %c  |  %c  |  %c  \n", map[0][0], map[0][1], map[0][2]);
	printf ("      |    |    \n\n");
	
	printf ("You are playing as 'T' and the bot is playing as 'Z'.\n");
	printf ("To make a move, enter the row and column using letters 'a', 'b', 'c'.\n");
	printf ("For example, to mark the top-left corner, input: a a\n");
	printf ("Enter your move (row[a-c] and column[a-c]): ");
	}
	
	int status = -1;
	int player = 1;
	
	int checkWin() {
		for (int row = 0; row < 3; row++) {
			if (map[row][0] == map[row][1] && map[row][1] == map[row][2]) return 1;
		}
		
		for (int column = 0; column < 3; column++) {
			if (map[0][column] == map[1][column] && map[1][column] == map[2][column]) return 1;
		}
		
		if (map[0][0] == map[1][1] && map[1][1] == map[2][2]) return 1;
		if (map[0][2] == map[1][1] && map[1][1] == map[2][0]) return 1;
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (map[i][j] != 'T' && map[i][j] != 'Z');
			}
		}
		return 0;
	}
	
	void botMove() {
		int row, column;
		srand (time(0));
		
		do {
			row = rand() % 3;
			column = rand() % 3;
		} while (map[row][column] == 'T' || map[row][column] == 'Z');
		
		map[row][column] = 'Z';
	}

int main () {
	
	printf ("Welcome to gaLactic Fear!\n");
	printf ("1. Play\n");
	printf ("2. Exit\n");
	printf ("Select an option: ");
	
	int menu, difficulty;
	
	scanf ("%d", &menu);
	
	system ("cls");
	
	if (menu == 1) {
		printf ("Select difficulty:\n");
		printf ("1. Easy\n");
		printf ("2. Hard\n");
		printf ("Select an option: ");
		scanf ("%d", &difficulty);
		
		system ("cls");
		
	} else if (menu == 2) {
		printf ("Exiting the game.\n");
	} else {
		printf ("Please input number 1 or 2\n");
	}
	
	char input1, input2;

	do {
		drawMap();

		if (player == 1) {
			scanf ("%c %c", &input1, &input2);
		
			if (input1 == 'a' && input2 == 'a' && map[0][0] == '1') map[0][0] = 'T';
			else if (input1 == 'a' && input2 == 'b' && map[0][1] == '2') map[0][1] = 'T';
			else if (input1 == 'a' && input2 == 'c' && map[0][2]) map[0][2] = 'T';
			else if (input1 == 'b' && input2 == 'a' && map[1][1]) map[1][0] = 'T';
			else if (input1 == 'b' && input2 == 'b' && map[1][2]) map[1][1] = 'T';
			else if (input1 == 'b' && input2 == 'c' && map[1][3]) map[1][2] = 'T';
			else if (input1 == 'c' && input2 == 'a' && map[2][0]) map[2][0] = 'T';
			else if (input1 == 'c' && input2 == 'b' && map[2][1]) map[2][1] = 'T';
			else if (input1 == 'c' && input2 == 'c' && map[2][2]) map[2][2] = 'T';
			else {
				printf ("Input tidak valid!\n");
				continue;
			}
		player = 2;
		} else {
			botMove();
			player = 1;
		}	
		status = checkWin();
	} while (status == -1);
	
	drawMap();
	
	if (status == 1) printf ("YEY %d MENANG\n", (player == 1) ? 2 : 1);
	else printf ("YEU KOCAK SERI\n");
	
	//kok ga ngeprint T sama Z ya outputnya, ini blom bikin difficulty lagi...
	
	return (0);
}
