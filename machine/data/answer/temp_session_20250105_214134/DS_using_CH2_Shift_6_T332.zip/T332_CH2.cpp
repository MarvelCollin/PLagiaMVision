#include <stdio.h>
#include <stdlib.h>

char map[3][3];
const char pemain = 'P';
const char bot = 'B';


void printboard(){
	printf(" %c | %c | %c \n", map[0][0], map[0][1], map[0][2]);
	printf("---|---|---\n");
	printf(" %c | %c | %c \n", map[1][0], map[1][1], map[1][2]);
	printf("---|---|---\n");
	printf(" %c | %c | %c \n", map[2][0], map[2][1], map[2][2]);
	}
void cekmenang(int x, int y){
    if(map[x][y]!=' ');
    if(map[x][y]==map[x+1][y]==map[x+2][y]||map[x][y+1]==map[x][y+1]==map[x][y+2]||map[x][y]==map[x+1][y+1]==map[x+2][y+2]||map[x][y]==map[x-1][y]==map[x-2][y]||map[x][y]==map[x][y-1]==map[x][y-2]){
   		printf("kamu menang!\n");
	   }
}
int cekposisi(int x, int y){

	int posisi = 9;
	if(map[x][y]=='P'|| map[x][y]=='B'){
        return 1;
		printf("invalid\n");
	}
	
	else{
		posisi--;
		return 0;
	}

	return posisi;
}
void turnpemain(){
	int x, y;
	printf("masukan angka 1-3 dengan format a b :D\n");
	cekposisi(x,y);
	cekmenang(x,y);
	
	scanf("%d %d",&x, &y);
	
	map[x-1][y-1]='P';
	
	printboard();
	
}
void turnbotmudah(){
	
    int x,y;
    x = rand()%3 ;y = rand()%3;
    map[x][y] = 'B';
    cekposisi(x,y);
    printboard();
}

void printmenang(){

}

int main(){
    
    int menu;
	
    
	
	printf("Selamat datang! mau ngapain kamu?\n");
	printf("1. Main\n2. Keluar\n>>");
	scanf("%d", &menu);
	getchar();
	
	if(menu==1){
	printf("mau difficulty apa?\n");
	printf("1. easy\n2. hard\n>>");
	scanf("%d", &menu);
	getchar();
	
	if(menu==1){	
		char pemenang=' ';
		printboard();
		while(pemenang ==' ' && cekposisi!=0){
    	turnpemain();
    	turnbotmudah();
    }
    }
    if(menu==2){
    	return 0;
	}
}
	return 0;
}

