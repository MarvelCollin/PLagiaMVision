#include <stdio.h>

int main(){
	printf("AWIKWG");
	if(true){
		return 1;
	}
	return 0;
}
