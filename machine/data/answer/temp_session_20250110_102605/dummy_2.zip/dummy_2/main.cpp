playerMove();
		winner = checkWinner();
			if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
		computerMove();
		winner = checkWinner();
			if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
