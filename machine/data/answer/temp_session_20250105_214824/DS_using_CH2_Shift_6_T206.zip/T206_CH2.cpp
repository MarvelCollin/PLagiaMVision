#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<windows.h>

char board[3][3];
int x, y;
int xlose, ylose;

int full()
{
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(board[i][j] == ' ') return 0;
		}
	}
	return 1;
}


char check()
{
	for(int i = 0; i < 3; i++)
	{
		if(board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] != ' ')return board[i][0];
	}
	for(int i = 0; i < 3; i++)
	{
		if(board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] != ' ')return board[0][i];
	}
	if(board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[1][1] != ' ')return board[0][0];
	if(board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[1][1] != ' ')return board[1][1];
	return 'l';
}
int losing()
{
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(board[i][j] == ' ')
			{
				board[i][j] = 'T';
				if(check() == 'T')
				{
					xlose = j;
					ylose = i;
					board[i][j] = ' ';
					return 1;
				}
				board[i][j] = ' ';
			}
		}
	}
	return 0;
}

int winning()
{
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(board[i][j] == ' ')
			{
				board[i][j] = 'Z';
				if(check() == 'Z')
				{
					return 1;
				}
				board[i][j] = ' ';
			}
		}
	}
	return 0;
}

int displayBoard()
{
	printf("%c|%c|%c\n", board[0][0], board[0][1], board[0][2]);
	printf("-|-|-\n");
	printf("%c|%c|%c\n", board[1][0], board[1][1], board[1][2]);
	printf("-|-|-\n");
	printf("%c|%c|%c\n", board[2][0], board[2][1], board[2][2]);
}

void play()
{
	while(1)
	{
		char a, b;
		do
		{
			system("cls");
			displayBoard();
			scanf("%c %c",&a, &b);getchar();
		}
		while((a != 'a' && a != 'b' && a != 'c') || ( b != 'a' && b != 'b' && b != 'c') || board[b - 'a'][a - 'a'] != ' ');
		x = a - 'a';
		y = b - 'a';
		board[y][x] = 'T';
		return; 
//		printf("You are playing as\'T\' and the bot is playing as \'Z\'.\n");
//		printf("\nTo make a move, enter the row and column using letters \''")
	}
}

void easy()
{
	srand(time(NULL));
	int x, y;
	do
	{
		x = rand() % 3;
		y = rand() % 3;
	}
	while(board[y][x] != ' ');
	board[y][x] = 'Z';
}
//int board = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}}
void hard()
{
	srand(time(NULL));
	int n = rand() % 9 + 8;
	if(n % 2 == 0)
	{
		if(!winning())
		{
			easy();
		}
	}
	else
	{
		if(!losing())
		{
			easy();
		}
		else
		{
			board[ylose][xlose] = 'Z';
		}
	}
}

int fibo(int n)
{
	if(n == 1 || n == 0)
	{
		return n;
	}
	return fibo(n - 1) + fibo(n - 2);
}


int homePage()
{
	printf("Welcome to gaLactic Fear!\n");
	printf("1. Play\n2. Exit\nSelect an option: ");
	int option;
	scanf("%d", &option);getchar();
	switch(option)
	{
		case 1:
			return 1;
		case 2: 
			return 10;
			break;
	}
}

int level()
{
	printf("Select difficulity:\n");
	printf("1. Easy\n");
	printf("2. Hard\n");
	printf("Select an option \n");
	int option;
	scanf("%d", &option); getchar();
	switch(option)
	{
		case 1:
			return 1;
		case 2: 
			return 10;
			break;
	}
}

int main()
{
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{	
			board[i][j] = ' ';
		}
	}
	int menu = 0;
	int lvl = 0;
	while(1)
	{
		switch (menu)
		{
			case 0:
				menu = homePage();
				break;
			case 1:
				system("cls");
				lvl = level();
				menu = 2;
				break;
			case 2:
				if(check() != 'l')\
				{
					menu = 8;
					break;
				} 
				play();
				menu = 3;
				break;
			case 3:
				if(check() != 'l')
				{
					menu = 8;
					break;
				} 
				if(full()) menu = 9;
				if(lvl == 1) easy();
				else hard();
				menu = 2;
				break;
			case 8:
				char winss;
				winss = check();
				system("cls");
				printf("%c Win\n", winss);
				return 0;
			case 9:
				system("cls");
				printf("draw\n", winss);
				return 0;
			case 10:
				return 0;
		}
	}
}
