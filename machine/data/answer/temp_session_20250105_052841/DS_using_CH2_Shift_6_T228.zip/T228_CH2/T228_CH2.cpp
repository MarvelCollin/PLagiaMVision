#include <stdio.h>
#include <stdlib.h>
#include <time.h>

char board(){
	char map[9] = { ' ', ' ', ' ', ' ', ' ',' ',' ',' ',' '};
	
	printf(" %c | %c | %c \n", map[0], map[1], map[2]);
	printf("---|---|---\n");
	printf(" %c | %c | %c \n", map[3], map[4], map[5]);
	printf("---|---|---\n");
	printf(" %c | %c | %c \n", map[6], map[7], map[8]);
}

char boardplayeasy(){
	char map[9] = { ' ', ' ', ' ', ' ', ' ',' ',' ',' ',' '};
	
	int mover,movec;
	srand(time(0));
	
	while(true){
		for(int i=0;i<31;i++){
			printf("\n");
		}
		printf(" %c | %c | %c \n", map[0], map[1], map[2]);
		printf("---|---|---\n");
		printf(" %c | %c | %c \n", map[3], map[4], map[5]);
		printf("---|---|---\n");
		printf(" %c | %c | %c \n", map[6], map[7], map[8]);
		
		printf("You are playing as 'T' and the bot is playing as 'Z'.\n\n");
		printf("To make a move, enter the row and column using numbers 1, 2, 3.\n");
		printf("For example, to mark the top-left corner, input: 1 1\n");
		printf("Enter your move (row[1-3] and column[1-3]): ");
		scanf("%d %d", &mover, &movec);
		if(mover==1){
			if(movec==1){
				map[0] = 'T';
			}
			else if(movec = 2){
				map[1] = 'T';	
			}
			else if(movec = 3){
				map[2] = 'T';	
			}
		}
		if(mover==2){
			if(movec==1){
				map[3] = 'T';
			}
			else if(movec = 2){
				map[4] = 'T';	
			}
			else if(movec = 3){
				map[5] = 'T';	
			}
		}
		if(mover==3){
			if(movec==1){
				map[6] = 'T';
			}
			else if(movec = 2){
				map[7] = 'T';	
			}
			else if(movec = 3){
				map[8] = 'T';	
			}
		}
		srand(time(0));
		int botX = rand()%8;
		int botY = rand()%8;
	}	
}

int fibonacci(int fibo){
	if(fibo==0){
		return 0;
	}
	else if(fibo==1){
		return 1;
	}
	else{
		return fibonacci(fibo-1) + fibonacci(fibo-2);
	}
}

void menu(){
	printf("Welcome to gaLatic Fear!\n");
	printf("1. Play\n");
	printf("2. Exit\n");
	printf("Select an option: ");
}

void difficult(){
	printf("Select difficulty: \n");
	printf("1. Easy\n");
	printf("2. Hard\n");
	printf("Select an option: ");
}

void exit(){
	printf("Exiting the game.");
}

int hard(){
	char mover,movec;
	printf("You are playing as 'T' and the bot is playing as 'Z'.\n\n");
	printf("To make a move, enter the row and column using numbers 1, 2, 3.\n");
	printf("For example, to mark the top-left corner, input: 1 1\n");
	printf("Enter your move (row[1-3] and column[1-3]): ");

	
	return mover,movec;
}

int main(){
	int option;
	int difficulty;
	menu();
	
	scanf("%d", &option);
	if(option == 1){
		difficult();
	}
	else if(option==2){
		exit();
	}
		
	scanf("%d", &difficulty);
	board();
	if(difficulty==1){
		boardplayeasy();
	}
	else if(difficulty == 2){
		hard();
	}
	
	return 0;
}
