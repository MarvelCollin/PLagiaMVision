#include <stdio.h>
#include <stdlib.h>



void random(){
	 
}

void fibonacci(int a){
	rand(16 & 8);
	if (a == 0) return 0;
	else if(a == 1) return 1;
	else return a * fibonacci(a - 1);	
}

int main(){
	int optionMenu, optionLevel;
	char x, y;
	int arr[2][2];
	
	do{
		printf("Welcome to galactic Fear!\n");
		printf("1. Play\n");
		printf("2. Exit\n");
		printf("Select an option:");
		scanf("%d", &optionMenu);
		printf("\n");
		
			if(optionMenu == 1){
				do{
				printf("Select difficulty:\n");
				printf("1. Easy\n");
				printf("2. Hard\n");
				printf("Select an option: ");
				scanf("%d", &optionLevel);
				printf("\n");
				
					if(optionLevel == 1){
						int i;
						for(i = 0; i < 4; i++){
					
							printf(" %c  | %c  | %c  ", arr[0][0], arr[0][1], arr[0][2]);
							printf("---|---|---");
							printf(" %c  | %c | %c  ", arr[1][0], arr[1][1], arr[1][2]);
							printf("---|---|---");
							printf(" %c  | %c  | %c  ", arr[2][0], arr[2][1], arr[2][2]);
							printf("\n");
							printf("You are playing as 'T' and the bot is playing as 'Z'\n");
							printf("\n");
							printf("To make a move, enter the row and column using letters 'a', 'b', 'c'\n");
							printf("For example, to mark the top-left corner, input: a a\n");
							printf("Enter your move (row[a-c] and column[a-c]):\n");
							scanf("%c %c", &x, &y);
							printf("\n");
							
							if(x = 'a'){
								if(y == 'a') arr[0][0] = 'T';
								else if(y == 'b') arr[0][1] = 'T';
								else arr[0][2] = 'T'; }
							else if(x = 'b'){
								if(y == 'a') arr[1][0] = 'T';
								else if(y == 'b') arr[1][1] = 'T';
								else arr[1][2] = 'T'; }
							else{
								if(y == 'a') arr[2][0] = 'T';
								else if(y == 'b') arr[2][1] = 'T';
								else arr[2][2] = 'T'; }
								
							random(a);
								
							}
						}
				} while(optionLevel!= 1 && optionLevel!=2); //while optionLevel
			}
			if(optionMenu == 2){
				printf("Relentlessy Move Forward And Achieve Our Dreams\n");
				return;
			}
		
	}
	 while(optionMenu != 1 && optionMenu !=2); //while optionMenu
 
	
	
	
	
	return 0;	
}



//













