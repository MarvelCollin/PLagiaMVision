#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

char map[3][3] = {
	{' ', ' ', ' '},
	{' ', ' ', ' '},
	{' ', ' ', ' '}
};


void showMap() {
	printf("\n\n");
	printf(" %c | %c | %c\n", map[0][0], map[0][1], map[0][2]);
	printf("----------\n");
	printf(" %c | %c | %c\n", map[1][0], map[1][1], map[1][2]);
	printf("----------\n");
	printf(" %c | %c | %c\n", map[2][0], map[2][1], map[2][2]);
	printf("\n\n");
}


			
int main() {
	
	int input;
	bool isPlayingGame;
	
	do {
		printf("Welcome to game!\n");
		printf("1. Play\n");
		printf("2. Exit\n");
	
		printf("Select an option:");
		scanf("%d", &input);
		
		switch(input) {
			case 1: {
				system("cls");
				
				bool isGameOver = false;

				int inputDiff;
				
				printf("Select Difficulty:\n");
				printf("1. Easy\n");
				printf("2. Hard\n");
				printf("Select an option:\n");
				scanf("%d", &inputDiff);
				
				if(inputDiff == 1) {
					do{
						system("cls");
		
						showMap();
	
						printf("You are playing as 'T' and the bot is playing as 'Z'\n\n");
						
						printf("To make a move, enter the row and column using letters 'a', 'b', 'c'.\n");
						printf("For example, to mark the top-left corner, input: a a\n");
						printf("Enter your move (row[a- c] and column[a-c]): ");
						
						
						char userRow, userCol;
						int translatedRow, translatedCol;
						
						scanf(" %c %c", &userRow, &userCol);
						
						switch(userRow) {
							case 'a': {
								translatedRow = 0;
								break;
							}
							case 'b': {
								translatedRow = 1;
								break;
							}
							case 'c': {
								translatedRow = 2;
								break;
							}
						}
						
						switch(userCol) {
							case 'a': {
								translatedCol = 0;
								break;
							}
							case 'b': {
								translatedCol = 1;
								break;
							}
							case 'c': {
								translatedCol = 2;
								break;
							}
						}
	
						if(map[translatedRow][translatedCol] != ' ') {
							printf("Move invalid");
							continue;
						} else {
							map[translatedRow][translatedCol] = 'T';					
						}
	
	
						srand(time(0));
						
						int botRow = rand() % 2;
						int botCol = rand() % 2;
						
					
						map[botRow][botCol] = 'Z';
						
//						Check horizontaly
							if(map[0][0] == 'T' && map[0][0] == map[0][1] && map[0][1] == map[0][2]) {
								printf("Congrats, you win!");
								isGameOver = true;		
							}

							if(map[1][0] == 'T' &&  map[1][0] == map[1][1] && map[1][1] == map[1][2]) {
								printf("Congrats, you win!");
								isGameOver = true;	
							}
							
							if(map[2][0] == 'T' &&  map[2][0] == map[2][1] && map[2][1] == map[2][2]) {
								printf("Congrats, you win!");
								isGameOver = true;	
							}
							
//							Check verticaly
							if(map[0][0] == 'T' &&  map[0][0] == map[1][0] && map[1][0] == map[2][0]) {
								printf("Congrats, you win!");
								isGameOver = true;	
							}
							
							if(map[0][1] == 'T' &&  map[0][1] == map[1][1] && map[1][1] == map[2][1]) {
								printf("Congrats, you win!");
								isGameOver = true;	
							}
							
							if(map[0][2] == 'T' &&  map[0][2] == map[1][2] && map[1][2] == map[2][2]) {
								printf("Congrats, you win!");
								isGameOver = true;	
							}																																		
						
						
						
						showMap();
						
					} while(!isGameOver);
					
				}
				
				break;
			} 
				
			
			case 2: {
				printf("\nGame is shutting down...");			
//				Sleep(300);
				isPlayingGame = false;	
				break;
			}
				
		}
	} while(isPlayingGame);
	
	return 0;
}
