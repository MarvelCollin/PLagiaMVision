#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

char board[3][3];
char x,y;

void clear(){
	while(getchar()!='\n');
}

void reset(){
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			board[i][j] = ' ';
		}
	}
}

void draw(){
	system("cls");
	for(int i=0;i<3;i++){
		printf("\n");
		for(int j=0;j<3;j++){
			if(j==2) printf(" %c ", board[i][j]);
			else printf(" %c |", board[i][j]);
		}
		printf("\n");
		
		if(i<2){
			for(int j=0;j<3;j++){
				if(j==2) printf("---");
				else printf("---|");
			}
		}
	}
	
}

int menu(){
	int option;
	int no;
	do{
		no=0;
		printf("Welcome to galactic Fear!\n1. Play\n2. Exit\n");
		printf("Select an option: ");
		int validInput = scanf("%d", &option);
		if(validInput==0 || option<1 || option>2){
			no=1;
			printf("Invalid Input. Please put a number between 1-2!");
			clear();
			Sleep(1500);
			system("cls");
		} else return option;
	} while (no==1);
	
	return 0;
}

int diffMenu(){
	int option;
	int no;
	do{
		no=0;
		printf("Select difficulty:\n1. Easy\n2. Hard\n");
		printf("Select an option: ");
		int validInput = scanf("%d", &option);
		if(validInput==0 || option<1 || option>2){
			no=1;
			printf("Invalid Input. Please put a number between 1-2!");
			clear();
			Sleep(1500);
			system("cls");
		} else return option;
	} while (no==1);
}

int checkWin(){
	for(int i=0;i<3;i++){
		if(board[0][i]==board[1][i] && board[1][i]==board[2][i] && board[0][i]!=' ') return 1;
		else if(board[i][0]==board[i][1] && board[i][1]==board[i][2] && board[i][0]!=' ') return 1;
	}
	if(board[0][0]==board[1][1] && board[1][1]==board[2][2] && board[0][0]!=' ') return 1;
	else if(board[0][2]==board[1][1] && board[1][1]==board[2][0] && board[0][2]!=' ') return 1;
	
	return 0;
}

int checkDraw(){
	int count=0;
	for(int i=0;i<3;i++){
		for(int j=0;j<3;j++){
			if(board[i][j]=='T'||board[i][j]=='Z') count++;
		}
	}
	if(count==9){
		return 1;
	} else return 0;
	
	return 0;
}

void easyBot(){
	int no;
	do{
		no=0;
		x = rand() % 3;
		y = rand() % 3;
		if(board[x][y]!=' '){
			no=1;
		}	
	} while (no==1);
	board[x][y] = 'Z';
}

int fibo(int num){
	if(num==0) return 0;
	else if (num==1) return 1;
	else return fibo(num-1) + fibo(num-2);
}



void hardBot(){
	int random = 8+rand()%8;
	int r = fibo(random);
	if(r%2==0){
		int attacked=0;
		for(int i=0;i<3;i++){
			if(board[0][i]=='Z' && board[1][i]=='Z' && board[2][i]==' '&& attacked==0){
				board[2][i]=='Z'; attacked=1;
			} else if(board[0][i]=='Z' && board[1][i]==' ' && board[2][i]=='Z'&& attacked==0){
				board[1][i]=='Z'; attacked=1;
			} else if(board[0][i]==' ' && board[1][i]=='Z' && board[2][i]=='Z'&& attacked==0){
				board[0][i]=='Z'; attacked=1;
			}
		}
		for(int i=0;i<3;i++){
			if(board[i][0]=='Z' && board[i][1]=='Z' && board[i][2]==' '&& attacked==0){
				board[i][2]=='Z'; attacked=1;
			} else if(board[i][0]=='Z' && board[i][1]==' ' && board[i][2]=='Z'&& attacked==0){
				board[i][1]=='Z'; attacked=1;
			} else if(board[i][0]==' ' && board[i][1]=='Z' && board[i][2]=='Z'&& attacked==0){
				board[i][0]=='Z'; attacked=1;
			}
		}
		
		if(board[0][0]=='Z' && board[1][1]=='Z' && board[2][2]==' '&& attacked==0){
			board[2][2]=='Z'; attacked=1;
		} else if(board[0][0]=='Z' && board[1][1]==' ' && board[2][2]=='Z'&& attacked==0){
			board[1][1]=='Z'; attacked=1;
		} else if(board[0][0]==' ' && board[1][1]=='Z' && board[2][2]=='Z'&& attacked==0){
			board[0][0]=='Z'; attacked=1;
		}
		else if(board[2][0]=='Z' && board[1][1]=='Z' && board[0][2]==' '&& attacked==0){
			board[2][2]=='Z'; attacked=1;
		} else if(board[2][0]=='Z' && board[1][1]==' ' && board[0][2]=='Z'&& attacked==0){
			board[1][1]=='Z'; attacked=1;
		} else if(board[2][0]==' ' && board[1][1]=='Z' && board[0][2]=='Z'&& attacked==0){
			board[0][0]=='Z'; attacked=1;
		} else if (attacked==0){
			easyBot();
		}
		
	} else {
		int defended=0;
		for(int i=0;i<3;i++){
			if(board[0][i]=='T' && board[1][i]=='T' && board[2][i]==' '&& defended==0){
				board[2][i]=='Z'; defended=1;
			} else if(board[0][i]=='T' && board[1][i]==' ' && board[2][i]=='T'&& defended==0){
				board[1][i]=='Z'; defended=1;
			} else if(board[0][i]==' ' && board[1][i]=='T' && board[2][i]=='T'&& defended==0){
				board[0][i]=='Z'; defended=1;
			}
		}
		for(int i=0;i<3;i++){
			if(board[i][0]=='T' && board[i][1]=='T' && board[i][2]==' '&& defended==0){
				board[i][2]=='Z'; defended=1;
			} else if(board[i][0]=='T' && board[i][1]==' ' && board[i][2]=='T'&& defended==0){
				board[i][1]=='Z'; defended=1;
			} else if(board[i][0]==' ' && board[i][1]=='T' && board[i][2]=='T'&& defended==0){
				board[i][0]=='Z'; defended=1;
			}
		}
		
		if(board[0][0]=='T' && board[1][1]=='T' && board[2][2]==' '&& defended==0){
			board[2][2]=='Z'; defended=1;
		} else if(board[0][0]=='T' && board[1][1]==' ' && board[2][2]=='T'&& defended==0){
			board[1][1]=='Z'; defended=1;
		} else if(board[0][0]==' ' && board[1][1]=='T' && board[2][2]=='T'&& defended==0){
			board[0][0]=='Z'; defended=1;
		}
		else if(board[2][0]=='T' && board[1][1]=='T' && board[0][2]==' '&& defended==0){
			board[2][2]=='Z'; defended=1;
		} else if(board[2][0]=='T' && board[1][1]==' ' && board[0][2]=='T'&& defended==0){
			board[1][1]=='Z'; defended=1;
		} else if(board[2][0]==' ' && board[1][1]=='T' && board[0][2]=='T'&& defended==0){
			board[0][0]=='Z'; defended=1;
		} else if (defended==0){
			easyBot();
		}
	}
}

void input(){
	int no;
	do{
		no=0;
		draw();
		printf("You are playing as 'T' and the bot is playing as 'Z'.\n\n");
		printf("To make a move, enter the row and column using letters 'a', 'b', 'c'.\nFor example, to mark the top-left corner, input: a a\n");
		printf("Enter your move (row[a-c] and column[a-c]): ");
		getchar();
		scanf("%c %c", &x, &y);
		if(x-'a'<0||x-'a'>2||y-'a'<0||y-'a'>2){
			printf("Invalid Input! Please put a letter between a-c!");
			clear();
			no=1;
		} else if(board[x-'a'][y-'a']!=' '){
			printf("Invalid Input! This cell has already been filled");
			clear();
			no=1;
		}
	} while (no==1);
	board[x-'a'][y-'a']='T';
}


int main(){
	srand(time(NULL));
	do{
		reset();
		system("cls");
		int option = menu();
		if(option==1){
			system("cls");
			int diff = diffMenu();
			int win, seri, player;
			if (diff==1){
				do{
					player=0;
					input();
					win= checkWin();
					if (win==1) break;
					seri = checkDraw();
					if (seri==1) break;
					player=1;
					easyBot();
					if (win==1) break;
					seri = checkDraw();
					if (seri==1) break;
					
				} while (1);
				
				draw();
				if(player==0 && win==1){
					printf("Congratulations! You Win!\n");
				} else if (seri==1){
					printf("It's a draw!\n'");
				} else if (player==1 && win==1){
					printf("The bot wins! Better luck next time.");
				}
				
				
			} else if (diff==2){
				do{
					player=0;
					input();
					win= checkWin();
					if (win==1) break;
					seri = checkDraw();
					if (seri==1) break;
					player=1;
					hardBot();
					if (win==1) break;
					seri = checkDraw();
					if (seri==1) break;
					
				} while (1);
				
				draw();
				if(player==0 && win==1){
					printf("Congratulations! You Win!\n");
				} else if (seri==1){
					printf("It's a draw!\n'");
				} else if (player==1 && win==1){
					printf("The bot wins! Better luck next time.");
				}	
			}
			printf("Press any key to return to the menu...");
			getchar();
			getchar();
		} else {
			system("cls");
			printf("Thank you for playing!\n\n");
			printf("Exiting...");
			Sleep(1500);
			return 0;
		}
	} while (1);
	
	return 0;
}