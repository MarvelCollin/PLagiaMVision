#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<windows.h>

char printmap(char map[5][5]){
	
	for(int i=0; i<5; i++){
		for(int j=0; j<5; j++){
			printf("%c", map[i][j]);
		}
		puts("");
	}

}


void easybot(char map[5][5],char x,char y){
	
	int emptytiles[1000];
	int botmoved = 1;
	
	if(x == 'a' && y == 'a'){
		map[0][0] = 'T';
	}
	
	
	while(botmoved != 0){
		
		srand(time(NULL));
		
		for(int i=0; i<2; i++){
			
			emptytiles[i] = rand() % 5;
		}
		
		if(map[emptytiles[0]][emptytiles[1]] != 'T' && map[emptytiles[0]][emptytiles[1]] != '|' && map[emptytiles[0]][emptytiles[1]] != '-'){
		
			map[emptytiles[0]][emptytiles[1]] = 'Z';
			botmoved = 0;
		}
	}
}

int wincond(char grid[5][5]){
	
	if(grid[0][0] == 'Z' && grid[0][3] == 'Z' && grid[0][5] == 'Z'){
		return 1;
	}

}


int main(){
	
	int gamewon = 3;
	char map[5][5] ={
		
	{' ','|',' ','|',' '},
	{'-','|','-','|','-'},
	{' ','|',' ','|',' '},
	{'-','|','-','|','-'},
	{' ','|',' ','|',' '},

	};
	
//	for(int i=0; i<5; i++){
//		for(int j=0; j<5; j++){
//			printf("%c", map[i][j]);
//		}
//		puts("");
//	}
	
	
	int option = 5;
	while(option != 1){
		
		
		printf("Welcome to Galactic Fear!\n");
		printf("1. Play\n");
		printf("2. Exit\n");
		printf("Select an Option: ");
		scanf("%d", &option);
		
		
		if(option == 2){
			puts("");
			printf("byeee\n");
			return 0;
		}
		
		for(int i = 0; i<30; i++){
			puts("");
		}	
	}
	//interface
	
	int diff = 5;
	while(diff != 1 && diff != 2){
		
		printf("Select Difficulty:\n");
		printf("1. Easy\n");
		printf("2. Hard\n");
		printf("Select an option: ");
		scanf("%d", &diff);
		
		if(diff == 1){
			
			
			while(gamewon != 1){
				int x,y;
				
				printmap(map);
		
				printf("Pick your move (a,a): ");
				scanf("%c %c", &x,&y);
				
				easybot(map,x,y);
				system("cls");
				
				gamewon = wincond(map);
			}
			printf("You win!\n");
		}else if(diff == 2){
			printf("Hard");
		}	
	}
	
	
	
	
	
	
	
	return 0;
}
