#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

char board [3][3];
const char PLAYER = 'T';
const char COMPUTER = 'Z';

void menu();
void resetBoard();
void printBoard();
int checkFreeSpaces();
void playerMove();
void computerMove();
char checkWinner();
void printWinner(char);
void difficulty();
void gamehard();
void gameeasy();

//int Fibonacci(int n){
//	
//	if(n == 0) return 0;
//	if(n == 1) return 1;
//	return fibonacci(n-1) + fibonacci (n-2);
//	
//	printf("Hasil Fibonacci : %d\n", hasilFibo);
//	
//}

int main(){
	
	menu();
	
	return 0;
}

void gameeasy(){

	char winner = ' ';
	
	resetBoard();
	
	while(winner == ' ' && checkFreeSpaces() != 0)
	{
		printBoard();
		
		printf("You are playing as 'T' and the bot is playing as 'Z'.\n\n");
		printf("To make a move, enter the row and column as numbers between 4 and 6.\n");
		printf("For example, to mark the top-left corner, input: 4 4\n");
	
		
		playerMove();
		winner = checkWinner();
		if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
		computerMove();
		winner = checkWinner();
		if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
	}
	
	printBoard();
	printWinner(winner);
}

void gamehard(){

	char winner = ' ';
	
	resetBoard();
	
	while(winner == ' ' && checkFreeSpaces() != 0)
	{
		printBoard();
		
		printf("You are playing as 'T' and the bot is playing as 'Z'.\n\n");
		printf("To make a move, enter the row and column as numbers between 4 and 6.\n");
		printf("For example, to mark the top-left corner, input: 4 4\n");
	
		
		playerMove();
		winner = checkWinner();
		if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
		computerMove();
		winner = checkWinner();
		if(winner != ' ' || checkFreeSpaces() == 0)
		{
			break;
		}
	}
	
	printBoard();
	printWinner(winner);
}

void menu(){
	int choice;
		printf("                                                           \n");
      	printf("            _               _   _        _____\n");
		printf(" __ _  __ _| |    __ _  ___| |_(_) ___  |  ___|__  __ _ _ __\n");
		printf("/  _  |/ _`| |   / _` |/ __| __| |/ __| | |_ / _ \/ _` | '__|\n");
		printf("| (_| | (_|| |__| (_| | (__| |_| | (__  |  _|  __/ (_| | |\n");
		printf(",\__,_|____|__,_|\___|\__|_|\__|_|\___| |__| \__,_\__._|_|\n");
		printf("|___/\n");
		
		printf("Welcome to gaLactic Fear!\n");
		printf("1. Play\n");
		printf("2. Exit\n");  
		printf("Select an option: ");
		scanf("%d", &choice);
		
		switch(choice){
			case 1:
				difficulty();
				break;
				
			case 2:
				break;
		}
}

void difficulty(){
	int choice;
	do{
		printf("Select difficulty:\n");
		printf("1. Easy\n");
		printf("2. Hard\n");
		printf("Select an option: ");
		scanf("%d", &choice);
		printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		
		switch(choice){
			case 1:
				gameeasy();
				break;
				
			case 2:
				gamehard();
				break;
			
			case 3:
				printf("Invalid option! Please choose 1 for Easy or 2 for Hard.\n");
				break;
		}
	}while (choice == 3);
}

void resetBoard()
{
	for(int i = 0; i<3; i++)
	{
		for(int j = 0; j<3; j++)
		{
			board[i][j] = ' ';
		}
	}
}


void printBoard()
{
	printf(" %c | %c | %c ", board[0][0], board[0][1], board[0][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[1][0], board[1][1], board[1][2]);
	printf("\n---|---|---\n");
	printf(" %c | %c | %c ", board[2][0], board[2][1], board[2][2]);
	printf("\n");
}


int checkFreeSpaces()
{
	int freeSpaces = 9;
	
	for(int i = 0; i < 3; i++)
	{
		for(int j = 0; j < 3; j++)
		{
			if(board[i][j] != ' ')
			{
				freeSpaces--;
			}
			
		}
	}
	return freeSpaces;
}


void playerMove()
{
	int x;
	int y;
	
	do 
	{
	printf("Enter your move (row[4-6] and column[4-6]): ");
	scanf("%d", &x);
	x-=4;
	scanf("%d", &y);
	y-=4;
	
	if(board[x][y] != ' ')
	{
		printf("Invalid Move!\n");	
	}
	else 
	{
		board[x][y] = PLAYER;
		break;
	}
	} while (board [x][y] != ' ');

}


void printWinner(char winner)
{
	if (winner == PLAYER)
	{
		printf("Congratulations! You win!");
	}
	else if (winner == COMPUTER)
	{
		printf("The bot wins! Better luck next time.");
	}
	else
	{
		printf("IT'S A TIE!");
	}
}

void computerMove()
{
	srand (time(0));
	int x;
	int y;
	
	if(checkFreeSpaces()>0)
	{
		do
		{
			x = rand() % 3;
			y = rand() % 3;
		} while (board[x][y] != ' ');
		
		board [x][y] = COMPUTER;
	}
	else
	{
		printWinner(' ');
	}
}


char checkWinner()
{
	//check row
	for (int i=0; i<3; i++)
	{
		if (board[i][0] == board [i][1] && board[i][0] == board [i][2])
		{
			return board [i][0];

		}
	}
	// check columns
	for (int i=0; i<3; i++)
	{
		if (board[0][i] == board [1][i] && board[0][i] == board [2][i])
		{
			return board [0][i];

		}
	}
	//check diagonals
	if (board[0][0] == board [1][1] && board[0][0] == board [2][2])
		{
			return board [0][0];

		}
	if (board[0][2] == board [1][1] && board[0][2] == board [2][0])
		{
			return board [0][2];

		}
	return ' ';
}
